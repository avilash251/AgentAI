"""
MQOptima — Intelligent MQ Inventory & Target State Agent Pipeline
LangGraph multi-agent pipeline with 5 specialised agents:

  Agent 1 — Discovery Agent      : Discovers QMs, queues, channels
  Agent 2 — Relationship Agent   : Maps producer/consumer flows
  Agent 3 — Anomaly Detector     : Surfaces unused/redundant objects & cycles
  Agent 4 — Target State Agent   : Gemini 2.5 Flash Lite — topology reasoning
  Agent 5 — Migration Planner    : Generates phased migration plan + report
"""

import json
import os
from typing import TypedDict, List, Dict, Any
from langgraph.graph import StateGraph, END
import google.generativeai as genai

# Configure Gemini — set GEMINI_API_KEY env var before running
genai.configure(api_key=os.environ.get("GEMINI_API_KEY", ""))

_gemini = genai.GenerativeModel(
    model_name="gemini-2.5-flash-lite",
    generation_config=genai.GenerationConfig(
        temperature=0.2,
        max_output_tokens=2048,
    ),
)

# ═══════════════════════════════════════════════════════
# SHARED STATE
# ═══════════════════════════════════════════════════════

class MQAgentState(TypedDict):
    csv_raw: str
    inventory:       Dict[str, Any]
    relationships:   Dict[str, Any]
    anomalies:       List[Dict[str, Any]]
    target_state:    Dict[str, Any]
    decisions:       List[Dict[str, Any]]
    migration_plan:  List[Dict[str, Any]]
    report:          Dict[str, Any]
    agent_logs:      List[str]


# ═══════════════════════════════════════════════════════
# AGENT 1 — DISCOVERY
# ═══════════════════════════════════════════════════════

def discovery_agent(state: MQAgentState) -> MQAgentState:
    """Parses CSV and builds a structured inventory of all MQ objects."""
    logs = state.get("agent_logs", [])
    logs.append("🔍 Discovery Agent: Parsing topology from CSV…")

    lines = state["csv_raw"].strip().split("\n")
    headers = [h.strip().lower() for h in lines[0].split(",")]

    rows = []
    for line in lines[1:]:
        vals = [v.strip() for v in line.split(",")]
        row = dict(zip(headers, vals))
        row["msg_rate"] = int(row.get("msg_rate", 0) or 0)
        row["is_active"] = (row.get("status", "").upper() == "RUNNING"
                            and row["msg_rate"] > 0)
        rows.append(row)

    # Queue Managers
    qm_names: set = set()
    for r in rows:
        qm_names.update([r["source_qm"], r["target_qm"]])

    queue_managers = {}
    for qm in qm_names:
        out_ch = [r for r in rows if r["source_qm"] == qm]
        in_ch  = [r for r in rows if r["target_qm"] == qm]
        apps   = {r["application"] for r in out_ch + in_ch if r.get("application")}
        queue_managers[qm] = {
            "name": qm,
            "outbound_channels": len(out_ch),
            "inbound_channels":  len(in_ch),
            "total_traffic":     sum(r["msg_rate"] for r in out_ch + in_ch),
            "applications":      sorted(apps),
            "active_channels":   len([r for r in out_ch + in_ch if r["is_active"]]),
        }

    # Channels
    channels = []
    for i, r in enumerate(rows):
        channels.append({
            "id":           f"e{i}",
            "name":         r["channel_name"],
            "type":         r.get("channel_type", "SENDER"),
            "source_qm":    r["source_qm"],
            "target_qm":    r["target_qm"],
            "source_queue": r.get("source_queue", ""),
            "target_queue": r.get("target_queue", ""),
            "status":       r.get("status", "UNKNOWN"),
            "msg_rate":     r["msg_rate"],
            "application":  r.get("application", ""),
            "is_active":    r["is_active"],
            "is_unused":    not r["is_active"],
            "in_cycle":     False,
        })

    # Queues
    queues: dict = {}
    for r in rows:
        for q_name, qm, role in [
            (r.get("source_queue"), r["source_qm"], "producer"),
            (r.get("target_queue"), r["target_qm"], "consumer"),
        ]:
            if q_name and q_name not in queues:
                queues[q_name] = {"name": q_name, "qm": qm, "role": role,
                                  "application": r.get("application", "")}

    inventory = {
        "queue_managers": queue_managers,
        "channels":       channels,
        "queues":         queues,
        "summary": {
            "total_qms":          len(queue_managers),
            "total_channels":     len(channels),
            "active_channels":    len([c for c in channels if c["is_active"]]),
            "inactive_channels":  len([c for c in channels if c["is_unused"]]),
            "total_queues":       len(queues),
            "applications":       sorted({r.get("application", "") for r in rows
                                          if r.get("application")}),
            "total_daily_msgs":   sum(r["msg_rate"] for r in rows),
        },
    }

    logs.append(
        f"✅ Discovery complete — {len(queue_managers)} QMs · "
        f"{len(channels)} channels · {len(queues)} queues"
    )
    return {**state, "inventory": inventory, "agent_logs": logs}


# ═══════════════════════════════════════════════════════
# AGENT 2 — RELATIONSHIP MAPPER
# ═══════════════════════════════════════════════════════

def relationship_agent(state: MQAgentState) -> MQAgentState:
    """Identifies producer/consumer pairs, application flows and traffic hubs."""
    logs = state["agent_logs"]
    logs.append("🔗 Relationship Agent: Mapping producer/consumer dependencies…")

    channels = state["inventory"]["channels"]

    app_flows: dict = {}
    producer_consumer = []

    for ch in channels:
        if not ch["is_active"]:
            continue
        app = ch.get("application", "Unknown")
        flow = {
            "producer_qm":    ch["source_qm"],
            "producer_queue": ch["source_queue"],
            "consumer_qm":    ch["target_qm"],
            "consumer_queue": ch["target_queue"],
            "channel":        ch["name"],
            "application":    app,
            "msg_rate":       ch["msg_rate"],
        }
        producer_consumer.append(flow)
        app_flows.setdefault(app, []).append(
            f"{ch['source_qm']}.{ch['source_queue']} → "
            f"{ch['target_qm']}.{ch['target_queue']}"
        )

    # Connectivity per QM
    qm_conn: dict = {}
    for ch in channels:
        if not ch["is_active"]:
            continue
        for qm in [ch["source_qm"], ch["target_qm"]]:
            qm_conn.setdefault(qm, {"in": 0, "out": 0, "traffic": 0})
        qm_conn[ch["source_qm"]]["out"]     += 1
        qm_conn[ch["target_qm"]]["in"]      += 1
        qm_conn[ch["source_qm"]]["traffic"] += ch["msg_rate"]
        qm_conn[ch["target_qm"]]["traffic"] += ch["msg_rate"]

    hubs = sorted(
        [{"qm": qm, "in_degree": v["in"], "out_degree": v["out"],
          "total_traffic": v["traffic"],
          "is_hub": v["in"] + v["out"] >= 4}
         for qm, v in qm_conn.items()],
        key=lambda x: x["in_degree"] + x["out_degree"],
        reverse=True,
    )

    critical_paths = sorted(producer_consumer, key=lambda x: x["msg_rate"],
                            reverse=True)[:5]

    relationships = {
        "producer_consumer":  producer_consumer,
        "application_flows":  app_flows,
        "connectivity":       qm_conn,
        "hubs":               hubs,
        "critical_paths":     critical_paths,
        "total_daily_msgs":   sum(ch["msg_rate"] for ch in channels),
    }

    hub_count = len([h for h in hubs if h["is_hub"]])
    logs.append(
        f"✅ Relationships mapped — {len(producer_consumer)} active flows · "
        f"{len(app_flows)} apps · {hub_count} hub QMs"
    )
    return {**state, "relationships": relationships, "agent_logs": logs}


# ═══════════════════════════════════════════════════════
# AGENT 3 — ANOMALY DETECTOR
# ═══════════════════════════════════════════════════════

def anomaly_agent(state: MQAgentState) -> MQAgentState:
    """Detects routing cycles, unused channels, fan violations, redundant paths."""
    logs = state["agent_logs"]
    logs.append("⚠️  Anomaly Agent: Scanning for issues and anti-patterns…")

    inventory  = state["inventory"]
    channels   = inventory["channels"]
    qms        = list(inventory["queue_managers"].keys())
    anomalies  = []

    # ── 1. Unused channels ──────────────────────────────
    for ch in channels:
        if ch["is_unused"]:
            anomalies.append({
                "type":           "UNUSED_CHANNEL",
                "severity":       "MEDIUM",
                "object":         ch["name"],
                "detail":         (f"Channel {ch['name']} ({ch['source_qm']} → "
                                   f"{ch['target_qm']}) is {ch['status']} "
                                   f"with {ch['msg_rate']} msg/day"),
                "recommendation": "Decommission after confirming no planned reuse",
                "impact":         "Reduces attack surface and config sprawl",
                "weak_link":      None,
            })

    # ── 2. Cycle detection (DFS WHITE/GRAY/BLACK) ───────
    adj: dict = {qm: [] for qm in qms}
    for ch in channels:
        if ch["is_active"]:
            adj[ch["source_qm"]].append(
                (ch["target_qm"], ch["name"], ch["msg_rate"])
            )

    WHITE, GRAY, BLACK = 0, 1, 2
    color  = {qm: WHITE for qm in qms}
    path:  list = []
    found_keys: set = set()
    cycles_found: list = []

    def dfs(u: str):
        color[u] = GRAY
        path.append(u)
        for v, ch_name, rate in adj.get(u, []):
            if color.get(v) == GRAY:
                start = path.index(v)
                cycle = path[start:] + [v]
                key = ",".join(sorted(cycle[:-1]))
                if key not in found_keys:
                    found_keys.add(key)
                    cycles_found.append(
                        {"nodes": cycle, "channel": ch_name, "rate": rate}
                    )
            elif color.get(v) == WHITE:
                dfs(v)
        path.pop()
        color[u] = BLACK

    for qm in qms:
        if color[qm] == WHITE:
            dfs(qm)

    for ci in cycles_found:
        cycle = ci["nodes"]
        cycle_edges = [
            ch for ch in channels
            if ch["is_active"] and any(
                ch["source_qm"] == cycle[i] and ch["target_qm"] == cycle[i + 1]
                for i in range(len(cycle) - 1)
            )
        ]
        # Mark cycle edges
        cycle_set = {f"{cycle[i]}->{cycle[i+1]}" for i in range(len(cycle)-1)}
        for ch in channels:
            if f"{ch['source_qm']}->{ch['target_qm']}" in cycle_set:
                ch["in_cycle"] = True

        min_edge = min(cycle_edges, key=lambda x: x["msg_rate"],
                       default=None)
        anomalies.append({
            "type":           "ROUTING_CYCLE",
            "severity":       "CRITICAL",
            "object":         " → ".join(cycle[:-1]),
            "detail":         (f"Circular routing: {' → '.join(cycle[:-1])} ↻  "
                               f"({len(cycle)-1} hops)"),
            "recommendation": (
                f"Break cycle by redirecting/removing "
                f"{min_edge['name'] if min_edge else 'lowest-traffic edge'} "
                f"({min_edge['msg_rate'] if min_edge else 0} msg/day)"
            ),
            "impact":         "Eliminates message storm risk and unbounded queue growth",
            "weak_link":      min_edge["name"] if min_edge else None,
        })

    # ── 3. Fan-in ────────────────────────────────────────
    in_deg: dict = {}
    for ch in channels:
        if ch["is_active"]:
            in_deg[ch["target_qm"]] = in_deg.get(ch["target_qm"], 0) + 1

    for qm, degree in in_deg.items():
        if degree > 3:
            sources = [c["source_qm"] for c in channels
                       if c["target_qm"] == qm and c["is_active"]]
            anomalies.append({
                "type":           "FAN_IN",
                "severity":       "MEDIUM",
                "object":         qm,
                "detail":         f"{qm} receives from {degree} sources: {', '.join(sources)}",
                "recommendation": f"Introduce aggregator QM upstream of {qm}",
                "impact":         f"Reduces incoming connections from {degree} to 1",
                "weak_link":      None,
            })

    # ── 4. Fan-out ───────────────────────────────────────
    out_deg: dict = {}
    for ch in channels:
        if ch["is_active"]:
            out_deg[ch["source_qm"]] = out_deg.get(ch["source_qm"], 0) + 1

    for qm, degree in out_deg.items():
        if degree > 3:
            targets = [c["target_qm"] for c in channels
                       if c["source_qm"] == qm and c["is_active"]]
            anomalies.append({
                "type":           "FAN_OUT",
                "severity":       "MEDIUM",
                "object":         qm,
                "detail":         f"{qm} dispatches to {degree} targets: {', '.join(targets)}",
                "recommendation": f"Apply pub/sub topic routing at {qm}",
                "impact":         "Decouples producers from consumers",
                "weak_link":      None,
            })

    # ── 5. Redundant direct paths ────────────────────────
    pair_channels: dict = {}
    for ch in channels:
        if ch["is_active"]:
            key = f"{ch['source_qm']}→{ch['target_qm']}"
            pair_channels.setdefault(key, []).append(ch["name"])

    for pair, names in pair_channels.items():
        if len(names) > 1:
            anomalies.append({
                "type":           "REDUNDANT_CHANNELS",
                "severity":       "LOW",
                "object":         pair,
                "detail":         f"Multiple active channels between {pair}: {', '.join(names)}",
                "recommendation": "Consolidate unless intentional load-balancing",
                "impact":         "Simplifies monitoring and reduces config drift",
                "weak_link":      None,
            })

    crit = len([a for a in anomalies if a["severity"] == "CRITICAL"])
    med  = len([a for a in anomalies if a["severity"] == "MEDIUM"])
    logs.append(
        f"✅ Anomaly scan complete — {len(anomalies)} issues "
        f"({crit} critical · {med} medium)"
    )
    return {**state, "anomalies": anomalies, "agent_logs": logs}


# ═══════════════════════════════════════════════════════
# AGENT 4 — TARGET STATE (GEMINI 2.5 FLASH LITE)
# ═══════════════════════════════════════════════════════

def target_state_agent(state: MQAgentState) -> MQAgentState:
    """Uses Gemini 2.5 Flash Lite to reason about optimal target topology and explain decisions."""
    logs = state["agent_logs"]
    logs.append("🎯 Target State Agent: Reasoning about optimal topology with Gemini 2.5 Flash Lite…")

    inventory      = state["inventory"]
    relationships  = state["relationships"]
    anomalies      = state["anomalies"]
    channels       = inventory["channels"]
    qms            = inventory["queue_managers"]

    context = {
        "summary":         inventory["summary"],
        "anomalies":       anomalies,
        "hubs":            relationships["hubs"],
        "critical_paths":  relationships["critical_paths"],
        "application_flows": dict(list(relationships["application_flows"].items())[:10]),
    }

    prompt = f"""You are a senior IBM MQ architect. Analyse this topology and define the ideal target state.

CURRENT TOPOLOGY SUMMARY:
{json.dumps(context, indent=2)}

ACTIVE CHANNELS:
{json.dumps([c for c in channels if c["is_active"]], indent=2)}

Return ONLY a valid JSON object (no markdown, no preamble) with this exact schema:
{{
  "architecture_pattern": "hub-spoke | mesh | pipeline | hybrid",
  "pattern_rationale": "2-3 sentence rationale",
  "target_qms": [
    {{
      "name": "QM_NAME",
      "role": "hub | spoke | gateway | aggregator | archive | decommission",
      "keep": true,
      "reason": "one sentence"
    }}
  ],
  "target_channels": [
    {{
      "action": "keep | remove | add | modify",
      "channel_name": "CHAN.NAME",
      "source_qm": "QM_A",
      "target_qm": "QM_B",
      "reason": "one sentence"
    }}
  ],
  "key_decisions": [
    {{
      "decision": "short title",
      "rationale": "2–3 sentence explanation of WHY",
      "trade_offs": "what is given up",
      "priority": "immediate | short-term | long-term"
    }}
  ]
}}"""

    raw_target: dict = {}
    try:
        resp = _gemini.generate_content(prompt)
        raw = resp.text.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw_target = json.loads(raw.strip())
    except Exception:
        raw_target = _fallback_target_state(channels, anomalies)

    # Build optimised edge list
    removed_by_llm = {
        tc["channel_name"]
        for tc in raw_target.get("target_channels", [])
        if tc["action"] == "remove"
    }
    unused_names = {ch["name"] for ch in channels if ch["is_unused"]}
    keep_channels = [
        ch for ch in channels
        if ch["is_active"] and ch["name"] not in removed_by_llm
    ]

    node_ids: set = set()
    for ch in keep_channels:
        node_ids.update([ch["source_qm"], ch["target_qm"]])

    target_state = {
        "architecture_pattern": raw_target.get("architecture_pattern", "hub-spoke"),
        "pattern_rationale":    raw_target.get("pattern_rationale", ""),
        "target_qms":           raw_target.get("target_qms", []),
        "target_channels":      raw_target.get("target_channels", []),
        "optimized_edges":      keep_channels,
        "optimized_nodes": [
            {
                "id":    qm,
                "role":  next((t["role"] for t in raw_target.get("target_qms", [])
                               if t["name"] == qm), "spoke"),
                **qms.get(qm, {}),
            }
            for qm in node_ids
        ],
        "removed_channels": list(removed_by_llm | unused_names),
        "metrics": {
            "original_channels":  len(channels),
            "target_channels":    len(keep_channels),
            "channels_removed":   len(channels) - len(keep_channels),
            "original_qms":       len(qms),
            "target_qms_count":   len(node_ids),
        },
    }

    decisions = raw_target.get("key_decisions", [])
    pattern   = raw_target.get("architecture_pattern", "hub-spoke")
    logs.append(
        f"✅ Target state defined — {pattern} pattern · "
        f"{len(keep_channels)} channels retained · "
        f"{len(decisions)} decisions explained"
    )
    return {**state, "target_state": target_state,
            "decisions": decisions, "agent_logs": logs}


def _fallback_target_state(channels: list, anomalies: list) -> dict:
    cycle_links  = {a["weak_link"] for a in anomalies
                    if a["type"] == "ROUTING_CYCLE" and a.get("weak_link")}
    unused_names = {ch["name"] for ch in channels if ch["is_unused"]}
    target_ch = []
    for ch in channels:
        if ch["name"] in cycle_links:
            target_ch.append({
                "action": "remove", "channel_name": ch["name"],
                "source_qm": ch["source_qm"], "target_qm": ch["target_qm"],
                "reason": "Breaks routing cycle"
            })
        elif ch["name"] in unused_names:
            target_ch.append({
                "action": "remove", "channel_name": ch["name"],
                "source_qm": ch["source_qm"], "target_qm": ch["target_qm"],
                "reason": "Unused/inactive channel"
            })
        else:
            target_ch.append({
                "action": "keep", "channel_name": ch["name"],
                "source_qm": ch["source_qm"], "target_qm": ch["target_qm"],
                "reason": "Active channel with traffic"
            })
    return {
        "architecture_pattern": "hub-spoke",
        "pattern_rationale":    "Default hub-spoke topology based on traffic analysis.",
        "target_qms":           [],
        "target_channels":      target_ch,
        "key_decisions": [
            {"decision": "Remove unused channels",
             "rationale": "Unused channels add no value and increase the attack surface.",
             "trade_offs": "None — channels carry zero traffic.",
             "priority": "immediate"},
            {"decision": "Break routing cycles",
             "rationale": "Cycles risk unbounded message amplification and queue overflow.",
             "trade_offs": "Application routing logic must be updated.",
             "priority": "immediate"},
        ],
    }


# ═══════════════════════════════════════════════════════
# AGENT 5 — MIGRATION PLANNER
# ═══════════════════════════════════════════════════════

def migration_planner_agent(state: MQAgentState) -> MQAgentState:
    """Generates a phased, ordered migration plan and final exportable report."""
    logs = state["agent_logs"]
    logs.append("📋 Migration Planner Agent: Generating phased migration plan…")

    anomalies     = state["anomalies"]
    target_state  = state["target_state"]
    decisions     = state["decisions"]
    inventory     = state["inventory"]
    relationships = state["relationships"]

    steps    = []
    step_num = 1

    # ── Phase 1 — Cleanup ────────────────────────────────
    unused_a = [a for a in anomalies if a["type"] == "UNUSED_CHANNEL"]
    if unused_a:
        steps.append({
            "step":       step_num,
            "phase":      "Phase 1 — Cleanup",
            "phase_key":  "cleanup",
            "title":      f"Decommission {len(unused_a)} unused channel(s)",
            "actions":    [f"Stop and delete {a['object']}" for a in unused_a],
            "risk":       "LOW",
            "effort":     "LOW",
            "duration":   "1–2 days",
            "validation": "Confirm zero traffic on each channel for ≥ 30 days before deletion",
            "rollback":   "Re-create channel definition from MQSC backup",
        })
        step_num += 1

    for ca in [a for a in anomalies if a["type"] == "ROUTING_CYCLE"]:
        steps.append({
            "step":       step_num,
            "phase":      "Phase 1 — Cleanup",
            "phase_key":  "cleanup",
            "title":      f"Break routing cycle: {ca['object'][:55]}…",
            "actions": [
                f"Identify application owning {ca.get('weak_link', 'cycle channel')}",
                "Replace synchronous response with async event/callback pattern",
                f"Disable/remove {ca.get('weak_link', 'cycle channel')}",
                "Monitor all queues in the cycle for 24 h post-change",
            ],
            "risk":       "HIGH",
            "effort":     "MEDIUM",
            "duration":   "3–5 days",
            "validation": "No message accumulation in any queue involved in the cycle",
            "rollback":   "Re-enable channel and revert application routing config",
        })
        step_num += 1

    # ── Phase 2 — Structural ──────────────────────────────
    for fa in [a for a in anomalies if a["type"] == "FAN_IN"]:
        agg = f"QM_AGG_{fa['object'].replace('QM_', '')}"
        steps.append({
            "step":      step_num,
            "phase":     "Phase 2 — Structural",
            "phase_key": "structural",
            "title":     f"Introduce aggregator upstream of {fa['object']}",
            "actions": [
                f"Provision new aggregator Queue Manager: {agg}",
                f"Define inbound channels from all senders → {agg}",
                f"Define single outbound channel: {agg} → {fa['object']}",
                "Update sending applications to target the aggregator",
                "Decommission direct channels to original target once stable",
            ],
            "risk":       "MEDIUM",
            "effort":     "HIGH",
            "duration":   "1–2 weeks",
            "validation": "All traffic flows through aggregator with zero message loss",
            "rollback":   "Keep old direct channels live in parallel until validated",
        })
        step_num += 1

    for fo in [a for a in anomalies if a["type"] == "FAN_OUT"]:
        steps.append({
            "step":      step_num,
            "phase":     "Phase 2 — Structural",
            "phase_key": "structural",
            "title":     f"Implement pub/sub routing at {fo['object']}",
            "actions": [
                f"Define topic-based routing on {fo['object']}",
                "Subscribe downstream QMs to relevant topics",
                "Remove point-to-point channels to each consumer",
                "Update producing application routing config",
            ],
            "risk":       "MEDIUM",
            "effort":     "HIGH",
            "duration":   "1–2 weeks",
            "validation": "All consumers receive messages via topic subscriptions",
            "rollback":   "Re-enable point-to-point channels",
        })
        step_num += 1

    # ── Phase 3 — Modernisation ───────────────────────────
    for dec in [d for d in decisions if d.get("priority") == "long-term"]:
        steps.append({
            "step":      step_num,
            "phase":     "Phase 3 — Modernisation",
            "phase_key": "modern",
            "title":     dec["decision"],
            "actions":   [dec["rationale"], f"Trade-offs: {dec.get('trade_offs','N/A')}"],
            "risk":       "LOW",
            "effort":     "HIGH",
            "duration":   "4–8 weeks",
            "validation": "Architecture review sign-off + integration test pass",
            "rollback":   "Revert to prior topology version",
        })
        step_num += 1

    # Always-last: observability
    steps.append({
        "step":      step_num,
        "phase":     "Phase 3 — Modernisation",
        "phase_key": "modern",
        "title":     "Implement topology observability and drift alerting",
        "actions": [
            "Deploy MQ channel monitoring with dead-letter queue alerting",
            "Automate complexity score tracking via MQOptima CI pipeline",
            "Configure alerts for new STOPPED channels",
            "Schedule quarterly topology review",
        ],
        "risk":       "LOW",
        "effort":     "MEDIUM",
        "duration":   "2–3 weeks",
        "validation": "All QMs reporting in dashboard with zero unack'd alerts",
        "rollback":   "N/A",
    })

    # ── Final Report ──────────────────────────────────────
    current_health = max(
        0,
        100 - (
            len([a for a in anomalies if a["type"] == "ROUTING_CYCLE"]) * 15
            + len([a for a in anomalies if a["type"] == "UNUSED_CHANNEL"]) * 5
            + len([a for a in anomalies if a["type"] in ("FAN_IN","FAN_OUT")]) * 8
        )
    )

    report = {
        "title":       "MQOptima — Intelligent Topology Assessment Report",
        "generated_at": "2026-03-19",
        "executive_summary": {
            "current_health":    current_health,
            "target_health":     min(100, current_health + 35),
            "total_issues":      len(anomalies),
            "critical_issues":   len([a for a in anomalies if a["severity"] == "CRITICAL"]),
            "recommended_pattern": target_state.get("architecture_pattern", "hub-spoke"),
            "pattern_rationale": target_state.get("pattern_rationale", ""),
        },
        "inventory":      inventory["summary"],
        "relationships": {
            "total_flows":    len(relationships["producer_consumer"]),
            "hub_qms":        [h["qm"] for h in relationships["hubs"] if h["is_hub"]],
            "critical_paths": relationships["critical_paths"],
        },
        "anomalies":      anomalies,
        "target_state": {
            "architecture_pattern": target_state.get("architecture_pattern"),
            "pattern_rationale":    target_state.get("pattern_rationale"),
            "metrics":              target_state.get("metrics", {}),
        },
        "key_decisions":    decisions,
        "migration_plan":   steps,
        "total_steps":      len(steps),
        "phases": {
            "cleanup":    len([s for s in steps if s["phase_key"] == "cleanup"]),
            "structural": len([s for s in steps if s["phase_key"] == "structural"]),
            "modern":     len([s for s in steps if s["phase_key"] == "modern"]),
        },
    }

    phases = len(set(s["phase"] for s in steps))
    logs.append(
        f"✅ Migration plan complete — {len(steps)} steps across {phases} phases"
    )
    logs.append("🎉 All 5 agents finished. Pipeline complete.")

    return {**state, "migration_plan": steps, "report": report,
            "agent_logs": logs}


# ═══════════════════════════════════════════════════════
# BUILD & RUN
# ═══════════════════════════════════════════════════════

def build_pipeline():
    g = StateGraph(MQAgentState)
    g.add_node("discovery",    discovery_agent)
    g.add_node("relationship", relationship_agent)
    g.add_node("anomaly",      anomaly_agent)
    g.add_node("target_state", target_state_agent)
    g.add_node("migration",    migration_planner_agent)

    g.set_entry_point("discovery")
    g.add_edge("discovery",    "relationship")
    g.add_edge("relationship", "anomaly")
    g.add_edge("anomaly",      "target_state")
    g.add_edge("target_state", "migration")
    g.add_edge("migration",    END)

    return g.compile()


_pipeline = build_pipeline()


def run_pipeline(csv_raw: str) -> dict:
    """Entry point — run the full 5-agent pipeline on a CSV string."""
    initial: MQAgentState = {
        "csv_raw":        csv_raw,
        "inventory":      {},
        "relationships":  {},
        "anomalies":      [],
        "target_state":   {},
        "decisions":      [],
        "migration_plan": [],
        "report":         {},
        "agent_logs":     [],
    }
    return dict(_pipeline.invoke(initial))
