// MQOptima — IBM MQ Topology Optimizer
// React + D3 + Gemini 2.5 Flash Lite

import { useState, useEffect, useRef, useCallback } from "react";
import * as d3 from "d3";

// ═══════════════════════════════════════════════════════
// SAMPLE DATA
// ═══════════════════════════════════════════════════════
const SAMPLE_CSV = `source_qm,target_qm,channel_name,channel_type,source_queue,target_queue,status,msg_rate,application
QM_CORE,QM_ORDER,CHAN.CORE.ORDER,SENDER,CORE.OUT,ORDER.IN,RUNNING,2400,OrderService
QM_ORDER,QM_PAYMENT,CHAN.ORDER.PAYMENT,SENDER,ORDER.OUT,PAYMENT.IN,RUNNING,1800,PaymentService
QM_PAYMENT,QM_CORE,CHAN.PAYMENT.CORE,SENDER,PAYMENT.OUT,CORE.IN,RUNNING,300,AuditLoop
QM_ORDER,QM_INVENTORY,CHAN.ORDER.INV,SENDER,ORDER.STOCK,INV.IN,RUNNING,900,InventoryService
QM_INVENTORY,QM_NOTIFY,CHAN.INV.NOTIFY,SENDER,INV.ALERT,NOTIFY.IN,RUNNING,300,NotifyService
QM_NOTIFY,QM_AUDIT,CHAN.NOTIFY.AUDIT,SENDER,NOTIFY.OUT,AUDIT.IN,RUNNING,150,AuditService
QM_AUDIT,QM_ARCHIVE,CHAN.AUDIT.ARCHIVE,SENDER,AUDIT.OUT,ARCH.IN,RUNNING,120,ArchiveService
QM_CORE,QM_LEGACY,CHAN.CORE.LEGACY,SENDER,CORE.LEGACY,LEGACY.IN,STOPPED,0,LegacyMigrated
QM_LEGACY,QM_ARCHIVE,CHAN.LEGACY.ARCH,SENDER,LEGACY.OUT,ARCH.IN,STOPPED,0,ArchivedFlow
QM_CORE,QM_PAYMENT,CHAN.CORE.PAY.OLD,SENDER,CORE.PAY,PAYMENT.DIRECT,STOPPED,0,OldDirect
QM_PAYMENT,QM_NOTIFY,CHAN.PAY.NOTIFY,SENDER,PAY.NOTIFY,NOTIFY.PAY,RUNNING,600,PayAlerts
QM_ORDER,QM_AUDIT,CHAN.ORDER.AUDIT,SENDER,ORDER.AUDIT,AUDIT.IN,RUNNING,400,AuditTrail
QM_PAYMENT,QM_AUDIT,CHAN.PAY.AUDIT,SENDER,PAY.AUDIT,AUDIT.IN,RUNNING,350,AuditTrail
QM_INVENTORY,QM_AUDIT,CHAN.INV.AUDIT,SENDER,INV.AUDIT,AUDIT.IN,RUNNING,120,AuditTrail
QM_ORDER,QM_CORE,CHAN.ORDER.CORE,SENDER,ORDER.RESP,CORE.RESP,RUNNING,500,OrderResponse
QM_INVENTORY,QM_CORE,CHAN.INV.CORE,SENDER,INV.RESP,CORE.RESP,RUNNING,200,InvResponse`;

// ═══════════════════════════════════════════════════════
// ALGORITHMS
// ═══════════════════════════════════════════════════════

function parseCSV(text) {
  const lines = text.trim().split("\n").filter(l => l.trim());
  if (lines.length < 2) return [];
  const headers = lines[0].split(",").map(h => h.trim().toLowerCase());
  return lines.slice(1).map(line => {
    const vals = line.split(",").map(v => v.trim());
    const row = {};
    headers.forEach((h, i) => row[h] = vals[i] || "");
    row.msg_rate = parseInt(row.msg_rate) || 0;
    row.is_unused = (row.status || "").toUpperCase() === "STOPPED" || row.msg_rate === 0;
    row.in_cycle = false;
    return row;
  }).filter(r => r.source_qm && r.target_qm);
}

function buildGraph(rows) {
  const nodeMap = new Map();
  const edges = rows.map((row, i) => {
    for (const qm of [row.source_qm, row.target_qm]) {
      if (!nodeMap.has(qm)) nodeMap.set(qm, { id: qm, totalTraffic: 0, inDegree: 0, outDegree: 0 });
    }
    nodeMap.get(row.source_qm).outDegree++;
    nodeMap.get(row.target_qm).inDegree++;
    nodeMap.get(row.source_qm).totalTraffic += row.msg_rate;
    nodeMap.get(row.target_qm).totalTraffic += row.msg_rate;
    return { ...row, edgeId: `e${i}` };
  });
  return { nodes: Array.from(nodeMap.values()), edges };
}

function detectCycles(nodes, edges) {
  const adj = new Map();
  nodes.forEach(n => adj.set(n.id, []));
  edges.forEach(e => { if (!e.is_unused) adj.get(e.source_qm)?.push(e.target_qm); });

  const cycles = [];
  const WHITE = 0, GRAY = 1, BLACK = 2;
  const color = new Map(nodes.map(n => [n.id, WHITE]));
  const path = [];

  function dfs(u) {
    color.set(u, GRAY);
    path.push(u);
    for (const v of (adj.get(u) || [])) {
      if (color.get(v) === GRAY) {
        const start = path.indexOf(v);
        const cycle = [...path.slice(start), v];
        const key = [...cycle.slice(0, -1)].sort().join(",");
        cycles.push({ nodes: cycle, key });
      } else if (color.get(v) === WHITE) {
        dfs(v);
      }
    }
    path.pop();
    color.set(u, BLACK);
  }

  nodes.forEach(n => { if (color.get(n.id) === WHITE) dfs(n.id); });

  // Deduplicate
  const seen = new Set();
  return cycles.filter(c => {
    if (seen.has(c.key)) return false;
    seen.add(c.key);
    return true;
  }).map(c => c.nodes);
}

function markCycleEdges(edges, cycles) {
  const cycleSet = new Set();
  cycles.forEach(c => {
    for (let i = 0; i < c.length - 1; i++) cycleSet.add(`${c[i]}->${c[i + 1]}`);
  });
  edges.forEach(e => { e.in_cycle = cycleSet.has(`${e.source_qm}->${e.target_qm}`); });
}

function analyzeFanPatterns(nodes, edges, threshold = 3) {
  const issues = [];
  nodes.forEach(n => {
    const activeIn = edges.filter(e => e.target_qm === n.id && !e.is_unused);
    const activeOut = edges.filter(e => e.source_qm === n.id && !e.is_unused);
    if (activeIn.length > threshold)
      issues.push({ type: "FAN_IN", qm: n.id, degree: activeIn.length, peers: activeIn.map(e => e.source_qm) });
    if (activeOut.length > threshold)
      issues.push({ type: "FAN_OUT", qm: n.id, degree: activeOut.length, peers: activeOut.map(e => e.target_qm) });
  });
  return issues;
}

function computeAvgHops(nodes, edges) {
  const adj = new Map();
  nodes.forEach(n => adj.set(n.id, []));
  edges.filter(e => !e.is_unused).forEach(e => adj.get(e.source_qm)?.push(e.target_qm));
  let total = 0, count = 0;
  nodes.forEach(src => {
    const dist = new Map([[src.id, 0]]);
    const q = [src.id];
    while (q.length) {
      const u = q.shift();
      for (const v of (adj.get(u) || [])) {
        if (!dist.has(v)) { dist.set(v, dist.get(u) + 1); q.push(v); total += dist.get(v); count++; }
      }
    }
  });
  return count > 0 ? parseFloat((total / count).toFixed(2)) : 0;
}

function calculateMetrics(nodes, edges, cycles, fanIssues) {
  const unused = edges.filter(e => e.is_unused);
  const avgHops = computeAvgHops(nodes, edges);
  const complexityScore = Math.min(100, Math.round(
    cycles.length * 15 + unused.length * 5 + fanIssues.length * 8 + Math.max(0, (avgHops - 2) * 8)
  ));
  return {
    totalChannels: edges.length,
    activeChannels: edges.filter(e => !e.is_unused).length,
    unusedChannels: unused.length,
    totalQMs: nodes.length,
    cycles: cycles.length,
    fanIssues: fanIssues.length,
    avgHops,
    complexityScore,
    healthScore: Math.max(0, 100 - complexityScore),
    totalTraffic: edges.reduce((s, e) => s + e.msg_rate, 0),
  };
}

function generateRecommendations(edges, cycles, fanIssues) {
  const recs = [];
  let rid = 1;
  const unused = edges.filter(e => e.is_unused);
  if (unused.length > 0) {
    recs.push({
      id: `R${String(rid++).padStart(2, "0")}`, priority: "HIGH", category: "Cleanup",
      title: `Decommission ${unused.length} unused channel(s)`,
      description: `Remove: ${unused.slice(0, 4).map(e => e.channel_name).join(", ")}${unused.length > 4 ? " …" : ""}. Confirm with application teams first.`,
      impact: `Removes ${unused.length} dead objects, reduces security attack surface`,
      effort: "LOW", channelsReduced: unused.length,
    });
  }
  cycles.forEach(cycle => {
    const cycleEdges = [];
    for (let i = 0; i < cycle.length - 1; i++) {
      const e = edges.find(e => e.source_qm === cycle[i] && e.target_qm === cycle[i + 1] && !e.is_unused);
      if (e) cycleEdges.push(e);
    }
    const minEdge = cycleEdges.length > 0 ? cycleEdges.reduce((m, e) => e.msg_rate < m.msg_rate ? e : m, cycleEdges[0]) : null;
    recs.push({
      id: `R${String(rid++).padStart(2, "0")}`, priority: "CRITICAL", category: "Cycle Breaking",
      title: `Break cycle: ${cycle.slice(0, -1).join(" → ")}`,
      description: `Circular routing detected. Lowest-traffic edge to remove/redirect: ${minEdge?.channel_name || "unknown"} (${minEdge?.msg_rate || 0} msg/day). Replace with event-driven async pattern.`,
      impact: "Eliminates infinite routing loop risk, reduces message amplification",
      effort: "MEDIUM", channelsReduced: 1,
    });
  });
  fanIssues.forEach(fi => {
    if (fi.type === "FAN_IN") {
      recs.push({
        id: `R${String(rid++).padStart(2, "0")}`, priority: "MEDIUM", category: "Fan-In Reduction",
        title: `Add aggregator upstream of ${fi.qm}`,
        description: `${fi.qm} receives from ${fi.degree} sources. Introduce a dedicated aggregator QM to consolidate upstream traffic into a single channel.`,
        impact: `Reduces incoming connections to ${fi.qm} by ${fi.degree - 1}`,
        effort: "HIGH", channelsReduced: fi.degree - 1,
      });
    } else {
      recs.push({
        id: `R${String(rid++).padStart(2, "0")}`, priority: "MEDIUM", category: "Fan-Out Reduction",
        title: `Apply pub/sub pattern at ${fi.qm}`,
        description: `${fi.qm} dispatches to ${fi.degree} targets. Introduce topic-based routing to decouple producer from consumers.`,
        impact: "Decouples consumers, simplifies onboarding of new services",
        effort: "HIGH", channelsReduced: Math.floor(fi.degree / 2),
      });
    }
  });
  return recs;
}

function buildOptimized(nodes, edges, cycles) {
  let opt = edges.filter(e => !e.is_unused).map(e => ({ ...e }));
  cycles.forEach(cycle => {
    const cycleEdges = [];
    for (let i = 0; i < cycle.length - 1; i++) {
      const e = opt.find(e => e.source_qm === cycle[i] && e.target_qm === cycle[i + 1]);
      if (e) cycleEdges.push(e);
    }
    if (cycleEdges.length > 0) {
      const minEdge = cycleEdges.reduce((m, e) => e.msg_rate < m.msg_rate ? e : m, cycleEdges[0]);
      opt = opt.filter(e => e.edgeId !== minEdge.edgeId);
    }
  });
  const nodeIds = new Set([...opt.map(e => e.source_qm), ...opt.map(e => e.target_qm)]);
  const optNodes = nodes
    .filter(n => nodeIds.has(n.id))
    .map(n => ({
      ...n,
      inDegree: opt.filter(e => e.target_qm === n.id).length,
      outDegree: opt.filter(e => e.source_qm === n.id).length,
      totalTraffic: opt.filter(e => e.source_qm === n.id || e.target_qm === n.id).reduce((s, e) => s + e.msg_rate, 0),
    }));
  return { nodes: optNodes, edges: opt };
}

// ═══════════════════════════════════════════════════════
// D3 FORCE GRAPH
// ═══════════════════════════════════════════════════════

function ForceGraph({ nodes, edges, height = 480, title = "" }) {
  const containerRef = useRef(null);
  const svgRef = useRef(null);

  useEffect(() => {
    if (!svgRef.current || !nodes.length) return;
    const W = containerRef.current?.offsetWidth || 800;
    const H = height;
    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();
    svg.attr("viewBox", `0 0 ${W} ${H}`).attr("width", W).attr("height", H);

    // Defs
    const defs = svg.append("defs");
    const glow = defs.append("filter").attr("id", "glow-f");
    glow.append("feGaussianBlur").attr("stdDeviation", "3.5").attr("result", "blur");
    const mg = glow.append("feMerge");
    mg.append("feMergeNode").attr("in", "blur");
    mg.append("feMergeNode").attr("in", "SourceGraphic");

    const addMarker = (id, color) => {
      defs.append("marker").attr("id", id)
        .attr("viewBox", "0 -5 10 10").attr("refX", 30).attr("refY", 0)
        .attr("markerWidth", 5).attr("markerHeight", 5).attr("orient", "auto")
        .append("path").attr("d", "M0,-5L10,0L0,5").attr("fill", color);
    };
    addMarker("arr-active", "#10b981");
    addMarker("arr-cycle", "#f59e0b");
    addMarker("arr-unused", "#ef444455");

    svg.append("rect").attr("width", W).attr("height", H).attr("fill", "#07101f").attr("rx", 10);

    const nodeData = nodes.map(n => ({ ...n }));
    const linkData = edges.map(e => ({ ...e }));

    const sim = d3.forceSimulation(nodeData)
      .force("link", d3.forceLink(linkData).id(d => d.id).distance(130).strength(0.4))
      .force("charge", d3.forceManyBody().strength(-500))
      .force("center", d3.forceCenter(W / 2, H / 2))
      .force("collide", d3.forceCollide(46));

    const g = svg.append("g");
    svg.call(d3.zoom().scaleExtent([0.2, 3]).on("zoom", ev => g.attr("transform", ev.transform)));

    // Links
    const link = g.append("g").selectAll("line").data(linkData).enter().append("line")
      .attr("stroke", d => d.is_unused ? "#ef444440" : d.in_cycle ? "#f59e0b" : "#10b981")
      .attr("stroke-width", d => d.is_unused ? 1 : Math.max(1.5, Math.min(4, d.msg_rate / 700)))
      .attr("stroke-dasharray", d => d.is_unused ? "5,4" : "none")
      .attr("opacity", d => d.is_unused ? 0.4 : 0.75)
      .attr("marker-end", d => `url(#${d.is_unused ? "arr-unused" : d.in_cycle ? "arr-cycle" : "arr-active"})`);
    link.append("title").text(d => `${d.channel_name}\n${d.source_qm} → ${d.target_qm}\nStatus: ${d.status} | Traffic: ${d.msg_rate} msg/day\nApp: ${d.application || "N/A"}`);

    // Node groups
    const getColor = d => {
      if (edges.some(e => (e.source_qm === d.id || e.target_qm === d.id) && e.in_cycle)) return "#ef4444";
      if (d.inDegree > 3) return "#f59e0b";
      if (d.outDegree > 3) return "#a855f7";
      if (d.inDegree === 0 && d.outDegree === 0) return "#475569";
      return "#3b82f6";
    };

    const node = g.append("g").selectAll("g").data(nodeData).enter().append("g")
      .attr("cursor", "grab")
      .call(d3.drag()
        .on("start", (ev, d) => { if (!ev.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
        .on("drag", (ev, d) => { d.fx = ev.x; d.fy = ev.y; })
        .on("end", (ev, d) => { if (!ev.active) sim.alphaTarget(0); d.fx = null; d.fy = null; })
      );

    node.append("circle").attr("r", d => Math.max(22, Math.min(34, 16 + d.totalTraffic / 350)))
      .attr("fill", d => getColor(d) + "25")
      .attr("stroke", getColor).attr("stroke-width", 2.5)
      .attr("filter", "url(#glow-f)");

    node.append("text").attr("text-anchor", "middle").attr("dy", "0.38em")
      .attr("font-size", 9.5).attr("font-family", "monospace").attr("fill", "#dde5f0").attr("font-weight", "700")
      .text(d => d.id.replace("QM_", ""));

    node.append("title").text(d => `${d.id}\nIn: ${d.inDegree} | Out: ${d.outDegree}\nTraffic: ${d.totalTraffic} msg/day`);

    sim.on("tick", () => {
      link.attr("x1", d => d.source.x).attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x).attr("y2", d => d.target.y);
      node.attr("transform", d => `translate(${d.x},${d.y})`);
    });

    return () => sim.stop();
  }, [nodes, edges, height]);

  return (
    <div ref={containerRef} style={{ width: "100%", borderRadius: 10, overflow: "hidden", border: "1px solid #1a2e50" }}>
      <svg ref={svgRef} style={{ display: "block", width: "100%" }} />
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// STYLES
// ═══════════════════════════════════════════════════════
const C = {
  bg: "#050c18", sur: "#0b1628", sur2: "#0f1e36",
  border: "#1a2e50", accent: "#00d9ff", violet: "#8b5cf6",
  green: "#10b981", yellow: "#f59e0b", red: "#ef4444", blue: "#3b82f6",
  text: "#dde5f0", muted: "#64748b", orange: "#f97316",
};
const font = "'JetBrains Mono', 'Cascadia Code', 'Courier New', monospace";

const S = {
  app: { minHeight: "100vh", background: C.bg, color: C.text, fontFamily: font, fontSize: 13 },
  hdr: { background: `linear-gradient(135deg, ${C.sur} 0%, ${C.sur2} 100%)`, borderBottom: `1px solid ${C.border}`, padding: "14px 28px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 100 },
  logoBox: { width: 44, height: 44, background: `linear-gradient(135deg, ${C.accent}, ${C.violet})`, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 },
  main: { maxWidth: 1440, margin: "0 auto", padding: "24px 20px" },
  card: (accent = C.border) => ({ background: C.sur, border: `1px solid ${C.border}`, borderLeft: `3px solid ${accent}`, borderRadius: 12, padding: "20px 22px" }),
  grid: (cols) => ({ display: "grid", gridTemplateColumns: `repeat(auto-fit, minmax(${cols}px, 1fr))`, gap: 16 }),
  tabs: { display: "flex", gap: 4, padding: "4px", background: C.sur, border: `1px solid ${C.border}`, borderRadius: 12, marginBottom: 24, overflowX: "auto" },
  tab: (a) => ({ padding: "8px 18px", borderRadius: 9, cursor: "pointer", fontFamily: font, fontSize: 12, fontWeight: a ? 600 : 400, color: a ? C.accent : C.muted, background: a ? C.sur2 : "transparent", border: a ? `1px solid ${C.border}` : "1px solid transparent", whiteSpace: "nowrap", transition: "all 0.15s" }),
  metVal: (c) => ({ fontSize: 34, fontWeight: 700, color: c, lineHeight: 1, letterSpacing: "-0.02em" }),
  metLbl: { fontSize: 10, color: C.muted, marginTop: 8, textTransform: "uppercase", letterSpacing: "0.06em" },
  sec: { background: C.sur, border: `1px solid ${C.border}`, borderRadius: 12, padding: "20px 22px", marginBottom: 18 },
  secTitle: { fontSize: 11, fontWeight: 700, color: C.accent, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 },
  badge: (c) => ({ display: "inline-block", padding: "2px 8px", borderRadius: 4, background: c + "22", color: c, fontSize: 10, fontWeight: 700, letterSpacing: "0.05em", whiteSpace: "nowrap" }),
  issueRow: (c) => ({ display: "flex", gap: 12, padding: "12px 14px", background: C.sur2, borderRadius: 8, marginBottom: 8, borderLeft: `3px solid ${c}` }),
  recCard: (c) => ({ background: C.sur2, borderRadius: 10, padding: "16px", marginBottom: 14, border: `1px solid ${c}30` }),
  bar: (pct, c) => ({ height: 6, background: c, borderRadius: 3, width: `${Math.min(100, pct)}%`, transition: "width 0.6s ease" }),
  upload: (drag) => ({ border: `2px dashed ${drag ? C.accent : C.border}`, borderRadius: 14, padding: "28px 20px", textAlign: "center", cursor: "pointer", background: drag ? C.accent + "0a" : C.sur, transition: "all 0.2s", marginBottom: 22 }),
  aiBox: { background: "linear-gradient(135deg, #0f1e36 0%, #0a1428 100%)", border: `1px solid ${C.violet}40`, borderRadius: 12, padding: "20px", marginBottom: 18 },
};

const priorityColor = { CRITICAL: C.red, HIGH: C.yellow, MEDIUM: C.blue, LOW: C.green };
const effortColor = { LOW: C.green, MEDIUM: C.yellow, HIGH: C.orange };

// ═══════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════
export default function App() {
  const [tab, setTab] = useState("overview");
  const [topo, setTopo] = useState(null);
  const [drag, setDrag] = useState(false);
  const [loading, setLoading] = useState(false);
  const [aiText, setAiText] = useState("");
  const [aiLoading, setAiLoading] = useState(false);

  const analyze = useCallback((csvText) => {
    setLoading(true);
    setTimeout(() => {
      const rows = parseCSV(csvText);
      const { nodes, edges } = buildGraph(rows);
      const cycles = detectCycles(nodes, edges);
      markCycleEdges(edges, cycles);
      const unused = edges.filter(e => e.is_unused);
      const fanIssues = analyzeFanPatterns(nodes, edges);
      const metrics = calculateMetrics(nodes, edges, cycles, fanIssues);
      const recommendations = generateRecommendations(edges, cycles, fanIssues);
      const opt = buildOptimized(nodes, edges, cycles);
      const optFan = analyzeFanPatterns(opt.nodes, opt.edges);
      const optMetrics = calculateMetrics(opt.nodes, opt.edges, [], optFan);
      setTopo({ nodes, edges, cycles, unused, fanIssues, metrics, recommendations, opt, optMetrics });
      setTab("overview");
      setLoading(false);
    }, 500);
  }, []);

  useEffect(() => { analyze(SAMPLE_CSV); }, []);

  const handleFile = f => { const r = new FileReader(); r.onload = e => analyze(e.target.result); r.readAsText(f); };

  const fetchAI = async () => {
    if (!topo) return;
    setAiLoading(true);
    setAiText("");
    const summary = {
      queueManagers: topo.metrics.totalQMs,
      totalChannels: topo.metrics.totalChannels,
      unusedChannels: topo.metrics.unusedChannels,
      cycles: topo.metrics.cycles,
      fanIssues: topo.metrics.fanIssues,
      avgHops: topo.metrics.avgHops,
      complexityScore: topo.metrics.complexityScore,
      healthScore: topo.metrics.healthScore,
      cycleDetails: topo.cycles.map(c => c.slice(0, -1).join(" → ")),
      fanDetails: topo.fanIssues.map(f => `${f.type} at ${f.qm} (degree ${f.degree})`),
      unusedChannels: topo.unused.map(e => e.channel_name),
    };
    try {
      const GEMINI_API_KEY = window.__GEMINI_API_KEY__ || "";
      const geminiEndpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=${GEMINI_API_KEY}`;
      const userPrompt = `You are an IBM MQ architecture expert. Analyze MQ topology issues and provide concise, actionable transformation guidance. Use clear sections with emojis. Be specific and technical.\n\nAnalyze this IBM MQ topology and provide a transformation roadmap:\n\n${JSON.stringify(summary, null, 2)}\n\nProvide:\n1. Architecture Assessment (2-3 sentences)\n2. Top 3 Priority Actions (numbered, specific)\n3. Modern Pattern Recommendations (event-driven, hub-spoke, etc.)\n4. Risk & Migration Notes\n\nBe concise and actionable.`;
      const res = await fetch(geminiEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: userPrompt }] }],
          generationConfig: { maxOutputTokens: 1024, temperature: 0.3 },
        }),
      });
      const data = await res.json();
      setAiText(data.candidates?.[0]?.content?.parts?.[0]?.text || "No response received.");
    } catch (e) {
      setAiText("Unable to reach Gemini API. Set window.__GEMINI_API_KEY__ or check your connection.");
    }
    setAiLoading(false);
  };

  // Gauge SVG for health score
  const HealthGauge = ({ score }) => {
    const color = score > 70 ? C.green : score > 40 ? C.yellow : C.red;
    const angle = -135 + (score / 100) * 270;
    const rad = (angle * Math.PI) / 180;
    const cx = 70, cy = 70, r = 54;
    const x = cx + r * Math.cos(rad);
    const y = cy + r * Math.sin(rad);
    return (
      <svg width="140" height="100" viewBox="0 0 140 100">
        <defs>
          <linearGradient id="gauge-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={C.red} />
            <stop offset="50%" stopColor={C.yellow} />
            <stop offset="100%" stopColor={C.green} />
          </linearGradient>
        </defs>
        <path d={`M ${cx - r * Math.cos(Math.PI * 45 / 180)} ${cy - r * Math.sin(Math.PI * 45 / 180)} A ${r} ${r} 0 1 1 ${cx + r * Math.cos(Math.PI * 45 / 180)} ${cy - r * Math.sin(Math.PI * 45 / 180)}`}
          fill="none" stroke="#1a2e50" strokeWidth="12" strokeLinecap="round" />
        <path d={`M ${cx - r * Math.cos(Math.PI * 45 / 180)} ${cy - r * Math.sin(Math.PI * 45 / 180)} A ${r} ${r} 0 1 1 ${cx + r * Math.cos(Math.PI * 45 / 180)} ${cy - r * Math.sin(Math.PI * 45 / 180)}`}
          fill="none" stroke="url(#gauge-grad)" strokeWidth="12" strokeLinecap="round"
          strokeDasharray={`${(score / 100) * 254} 254`} />
        <line x1={cx} y1={cy} x2={x} y2={y} stroke={color} strokeWidth="2.5" strokeLinecap="round" />
        <circle cx={cx} cy={cy} r="5" fill={color} />
        <text x={cx} y={cy + 24} textAnchor="middle" fill={color} fontSize="20" fontWeight="700" fontFamily={font}>{score}</text>
        <text x={cx} y={cy + 36} textAnchor="middle" fill={C.muted} fontSize="8" fontFamily={font}>HEALTH</text>
      </svg>
    );
  };

  return (
    <div style={S.app}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0} ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-track{background:#0b1628} ::-webkit-scrollbar-thumb{background:#1a2e50;border-radius:3px}
        button:focus{outline:none}`}</style>

      {/* Header */}
      <div style={S.hdr}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={S.logoBox}>⬡</div>
          <div>
            <div style={{ fontSize: 17, fontWeight: 700, letterSpacing: "-0.01em" }}>
              MQ<span style={{ color: C.accent }}>Optima</span>
            </div>
            <div style={{ fontSize: 10, color: C.muted }}>IBM MQ Topology Intelligence Platform</div>
          </div>
        </div>
        {topo && (
          <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
            {[
              { label: "QMs", val: topo.metrics.totalQMs, c: C.blue },
              { label: "Channels", val: topo.metrics.totalChannels, c: C.accent },
              { label: "Cycles", val: topo.metrics.cycles, c: topo.metrics.cycles > 0 ? C.red : C.green },
              { label: "Issues", val: topo.metrics.unusedChannels + topo.metrics.fanIssues, c: C.yellow },
            ].map(m => (
              <div key={m.label} style={{ textAlign: "center" }}>
                <div style={{ fontSize: 18, fontWeight: 700, color: m.c }}>{m.val}</div>
                <div style={{ fontSize: 10, color: C.muted, textTransform: "uppercase" }}>{m.label}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={S.main}>
        {/* Upload Zone */}
        <div style={S.upload(drag)}
          onDragOver={e => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={e => { e.preventDefault(); setDrag(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
          onClick={() => document.getElementById("fi").click()}>
          <input id="fi" type="file" accept=".csv" style={{ display: "none" }} onChange={e => e.target.files[0] && handleFile(e.target.files[0])} />
          <div style={{ fontSize: 28, marginBottom: 6 }}>📂</div>
          <div style={{ color: C.muted, fontSize: 12 }}>
            {loading ? "⚙ Analyzing topology…" : "Drop CSV or click to upload   ·   Demo data active"}
          </div>
          <div style={{ color: C.border, fontSize: 10, marginTop: 6 }}>
            Columns: source_qm, target_qm, channel_name, channel_type, source_queue, target_queue, status, msg_rate, application
          </div>
        </div>

        {topo && (
          <>
            {/* Tabs */}
            <div style={S.tabs}>
              {[
                { id: "overview", label: "Overview" },
                { id: "graph", label: "Topology Graph" },
                { id: "issues", label: `Issues  ${topo.metrics.cycles + topo.metrics.unusedChannels + topo.metrics.fanIssues > 0 ? "●" : ""}` },
                { id: "recommendations", label: "Recommendations" },
                { id: "optimized", label: "Optimized View" },
                { id: "ai", label: "✦ AI Insights" },
                { id: "agent", label: "⬡ Agent Pipeline" },
              ].map(t => (
                <button key={t.id} style={S.tab(tab === t.id)} onClick={() => setTab(t.id)}>
                  {t.label}
                </button>
              ))}
            </div>

            {/* ─── OVERVIEW ─── */}
            {tab === "overview" && (
              <>
                <div style={{ display: "flex", gap: 16, marginBottom: 18, flexWrap: "wrap", alignItems: "stretch" }}>
                  {/* Gauge */}
                  <div style={{ ...S.card(topo.metrics.healthScore > 70 ? C.green : topo.metrics.healthScore > 40 ? C.yellow : C.red), display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minWidth: 160 }}>
                    <HealthGauge score={topo.metrics.healthScore} />
                    <div style={{ fontSize: 10, color: C.muted, textTransform: "uppercase", letterSpacing: "0.06em" }}>Topology Health</div>
                  </div>
                  {/* Metrics */}
                  <div style={{ flex: 1, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12 }}>
                    {[
                      { label: "Total Channels", val: topo.metrics.totalChannels, c: C.accent },
                      { label: "Active Channels", val: topo.metrics.activeChannels, c: C.green },
                      { label: "Unused / Dead", val: topo.metrics.unusedChannels, c: C.red },
                      { label: "Queue Managers", val: topo.metrics.totalQMs, c: C.violet },
                      { label: "Cycles Detected", val: topo.metrics.cycles, c: topo.metrics.cycles > 0 ? C.red : C.green },
                      { label: "Fan Violations", val: topo.metrics.fanIssues, c: C.orange },
                      { label: "Avg Hops", val: topo.metrics.avgHops, c: C.blue },
                      { label: "Complexity Score", val: topo.metrics.complexityScore, c: topo.metrics.complexityScore > 50 ? C.red : topo.metrics.complexityScore > 25 ? C.yellow : C.green },
                    ].map(m => (
                      <div key={m.label} style={S.card(m.c)}>
                        <div style={S.metVal(m.c)}>{m.val}</div>
                        <div style={S.metLbl}>{m.label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Complexity Breakdown */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  <div style={S.sec}>
                    <div style={S.secTitle}>⚡ Complexity Breakdown</div>
                    {[
                      { label: "Cycles", pts: topo.metrics.cycles * 15, max: 60, c: C.red },
                      { label: "Unused Channels", pts: topo.metrics.unusedChannels * 5, max: 40, c: C.yellow },
                      { label: "Fan Violations", pts: topo.metrics.fanIssues * 8, max: 40, c: C.orange },
                      { label: "Hop Overhead", pts: Math.max(0, Math.round((topo.metrics.avgHops - 2) * 8)), max: 30, c: C.blue },
                    ].map(item => (
                      <div key={item.label} style={{ marginBottom: 14 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                          <span style={{ color: C.muted, fontSize: 11 }}>{item.label}</span>
                          <span style={{ color: item.c, fontSize: 11, fontWeight: 600 }}>{item.pts} pts</span>
                        </div>
                        <div style={{ height: 6, background: "#0f1e36", borderRadius: 3 }}>
                          <div style={S.bar(item.max > 0 ? (item.pts / item.max) * 100 : 0, item.c)} />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div style={S.sec}>
                    <div style={S.secTitle}>📉 Optimization Potential</div>
                    {[
                      { label: "Channels (current → optimized)", before: topo.metrics.totalChannels, after: topo.optMetrics.activeChannels, c: C.green },
                      { label: "Cycles → eliminated", before: topo.metrics.cycles, after: 0, c: C.red },
                      { label: "Avg hops", before: topo.metrics.avgHops, after: topo.optMetrics.avgHops, c: C.blue },
                      { label: "Complexity score", before: topo.metrics.complexityScore, after: topo.optMetrics.complexityScore, c: C.yellow },
                      { label: "Health score", before: topo.metrics.healthScore, after: topo.optMetrics.healthScore, c: C.green },
                    ].map(item => (
                      <div key={item.label} style={{ display: "flex", justifyContent: "space-between", padding: "9px 0", borderBottom: `1px solid ${C.border}` }}>
                        <span style={{ color: C.muted, fontSize: 11 }}>{item.label}</span>
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <span style={{ color: "#475569", fontSize: 13 }}>{item.before}</span>
                          <span style={{ color: C.border, fontSize: 10 }}>→</span>
                          <span style={{ color: item.c, fontSize: 13, fontWeight: 700 }}>{item.after}</span>
                          {item.before !== item.after && (
                            <span style={{ fontSize: 10, color: item.after < item.before ? C.green : C.red }}>
                              {item.after < item.before ? `▼ ${item.before - item.after}` : `▲ ${item.after - item.before}`}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* ─── GRAPH ─── */}
            {tab === "graph" && (
              <div style={S.sec}>
                <div style={S.secTitle}>🔗 Current MQ Topology — Original State</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 14, marginBottom: 14 }}>
                  {[
                    { c: C.green, label: "Active channel", dashed: false },
                    { c: C.yellow, label: "Cycle edge", dashed: false },
                    { c: "#ef444455", label: "Unused / STOPPED", dashed: true },
                    { c: C.red, label: "Node in cycle" },
                    { c: C.yellow, label: "High fan-in node" },
                    { c: "#a855f7", label: "High fan-out node" },
                    { c: C.blue, label: "Normal QM" },
                  ].map(l => (
                    <div key={l.label} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                      <div style={{ width: 22, height: 0, borderTop: `2.5px ${l.dashed ? "dashed" : "solid"} ${l.c}` }} />
                      <span style={{ fontSize: 10, color: C.muted }}>{l.label}</span>
                    </div>
                  ))}
                </div>
                <ForceGraph nodes={topo.nodes} edges={topo.edges} height={500} />
                <div style={{ fontSize: 10, color: C.muted, marginTop: 8 }}>Drag to reposition · Scroll to zoom · Hover edges and nodes for details</div>
              </div>
            )}

            {/* ─── ISSUES ─── */}
            {tab === "issues" && (
              <>
                <div style={S.sec}>
                  <div style={S.secTitle}>🔴 Routing Cycles ({topo.cycles.length})</div>
                  {topo.cycles.length === 0
                    ? <div style={{ color: C.green, fontSize: 12 }}>✓ No cycles detected</div>
                    : topo.cycles.map((cycle, i) => {
                      const cycleEdges = [];
                      for (let j = 0; j < cycle.length - 1; j++) {
                        const e = topo.edges.find(e => e.source_qm === cycle[j] && e.target_qm === cycle[j + 1]);
                        if (e) cycleEdges.push(e);
                      }
                      const minE = cycleEdges.length > 0 ? cycleEdges.reduce((m, e) => e.msg_rate < m.msg_rate ? e : m, cycleEdges[0]) : null;
                      return (
                        <div key={i} style={S.issueRow(C.red)}>
                          <div style={{ paddingTop: 1 }}><span style={S.badge(C.red)}>CYCLE</span></div>
                          <div>
                            <div style={{ marginBottom: 5, fontWeight: 600 }}>{cycle.slice(0, -1).join(" → ")} ↻</div>
                            <div style={{ color: C.muted, fontSize: 11, lineHeight: 1.6 }}>
                              {cycle.length - 1} hop(s) · Applications: {[...new Set(cycleEdges.map(e => e.application).filter(Boolean))].join(", ") || "N/A"}<br />
                              {minE && <span>Suggested break point: <span style={{ color: C.yellow }}>{minE.channel_name}</span> ({minE.msg_rate} msg/day — lowest traffic)</span>}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>

                <div style={S.sec}>
                  <div style={S.secTitle}>🟡 Unused / Inactive Channels ({topo.unused.length})</div>
                  {topo.unused.length === 0
                    ? <div style={{ color: C.green, fontSize: 12 }}>✓ No unused channels</div>
                    : topo.unused.map(e => (
                      <div key={e.channel_name} style={S.issueRow(C.yellow)}>
                        <span style={S.badge(C.yellow)}>UNUSED</span>
                        <div>
                          <div style={{ fontWeight: 600, marginBottom: 4 }}>{e.channel_name}</div>
                          <div style={{ color: C.muted, fontSize: 11 }}>
                            {e.source_qm} → {e.target_qm} · Status: <span style={{ color: C.red }}>{e.status}</span> · Traffic: {e.msg_rate} msg/day · App: {e.application || "N/A"}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>

                <div style={S.sec}>
                  <div style={S.secTitle}>🟠 Fan-In / Fan-Out Violations ({topo.fanIssues.length})</div>
                  {topo.fanIssues.length === 0
                    ? <div style={{ color: C.green, fontSize: 12 }}>✓ No fan pattern violations (threshold: degree &gt; 3)</div>
                    : topo.fanIssues.map((f, i) => (
                      <div key={i} style={S.issueRow(C.orange)}>
                        <span style={S.badge(C.orange)}>{f.type.replace("_", "-")}</span>
                        <div>
                          <div style={{ fontWeight: 600, marginBottom: 4 }}>{f.qm} — degree {f.degree}</div>
                          <div style={{ color: C.muted, fontSize: 11 }}>
                            {f.type === "FAN_IN" ? "Receives from" : "Sends to"}: {f.peers.join(", ")}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </>
            )}

            {/* ─── RECOMMENDATIONS ─── */}
            {tab === "recommendations" && (
              <div style={S.sec}>
                <div style={S.secTitle}>🎯 Actionable Recommendations ({topo.recommendations.length})</div>
                <div style={{ marginBottom: 16, display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 11, color: C.muted }}>Total channels reducible:</span>
                  <span style={{ color: C.green, fontWeight: 700 }}>
                    −{topo.recommendations.reduce((s, r) => s + r.channelsReduced, 0)}
                  </span>
                </div>
                {topo.recommendations.map(rec => (
                  <div key={rec.id} style={S.recCard(priorityColor[rec.priority] || C.border)}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10, flexWrap: "wrap", gap: 8 }}>
                      <div style={{ display: "flex", gap: 7, alignItems: "center" }}>
                        <span style={{ color: C.muted, fontSize: 10 }}>{rec.id}</span>
                        <span style={S.badge(priorityColor[rec.priority] || C.muted)}>{rec.priority}</span>
                        <span style={S.badge(C.muted)}>{rec.category}</span>
                      </div>
                      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                        <span style={{ fontSize: 10, color: C.muted }}>Effort:</span>
                        <span style={S.badge(effortColor[rec.effort] || C.muted)}>{rec.effort}</span>
                        <span style={{ fontSize: 10, color: C.green }}>−{rec.channelsReduced} channels</span>
                      </div>
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 7 }}>{rec.title}</div>
                    <div style={{ fontSize: 11, color: C.muted, marginBottom: 10, lineHeight: 1.65 }}>{rec.description}</div>
                    <div style={{ fontSize: 11, color: C.green, background: C.green + "12", padding: "7px 12px", borderRadius: 7 }}>
                      ↑ {rec.impact}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ─── OPTIMIZED ─── */}
            {tab === "optimized" && (
              <>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 14, marginBottom: 18 }}>
                  {[
                    { label: "Channels Removed", val: `−${topo.metrics.totalChannels - topo.optMetrics.activeChannels}`, c: C.green },
                    { label: "Cycles Eliminated", val: `−${topo.metrics.cycles}`, c: C.green },
                    { label: "Complexity Delta", val: `−${topo.metrics.complexityScore - topo.optMetrics.complexityScore} pts`, c: C.green },
                    { label: "New Health Score", val: topo.optMetrics.healthScore, c: topo.optMetrics.healthScore > 70 ? C.green : C.yellow },
                    { label: "Remaining Channels", val: topo.optMetrics.activeChannels, c: C.accent },
                    { label: "New Avg Hops", val: topo.optMetrics.avgHops, c: C.blue },
                  ].map(m => (
                    <div key={m.label} style={S.card(m.c)}>
                      <div style={S.metVal(m.c)}>{m.val}</div>
                      <div style={S.metLbl}>{m.label}</div>
                    </div>
                  ))}
                </div>
                <div style={S.sec}>
                  <div style={S.secTitle}>✨ Optimized Topology — Post-Transformation</div>
                  <div style={{ display: "flex", gap: 10, marginBottom: 12, flexWrap: "wrap" }}>
                    <span style={{ ...S.badge(C.red), marginRight: 4 }}>Removed</span>
                    <span style={{ fontSize: 11, color: C.muted }}>Unused channels removed · Cycle-breaking edges eliminated · Simplified routing paths</span>
                  </div>
                  <ForceGraph nodes={topo.opt.nodes} edges={topo.opt.edges} height={500} />
                </div>
              </>
            )}

            {/* ─── AI INSIGHTS ─── */}
            {tab === "ai" && (
              <div>
                <div style={S.aiBox}>
                  <div style={{ ...S.secTitle, color: C.violet }}>✦ AI-Powered Architecture Analysis</div>
                  <div style={{ fontSize: 11, color: C.muted, marginBottom: 16, lineHeight: 1.7 }}>
                    Send the topology analysis to Gemini 2.5 Flash Lite for an expert assessment of transformation strategies, risk areas, and modernization patterns tailored to your MQ environment.
                  </div>
                  <button
                    onClick={fetchAI}
                    disabled={aiLoading}
                    style={{ padding: "10px 24px", background: aiLoading ? C.sur2 : `linear-gradient(135deg, ${C.violet}, ${C.accent}30)`, border: `1px solid ${C.violet}`, borderRadius: 8, color: C.text, fontFamily: font, fontSize: 12, cursor: aiLoading ? "wait" : "pointer", fontWeight: 600, letterSpacing: "0.04em" }}>
                    {aiLoading ? "⚙ Analyzing…" : "✦ Run AI Analysis"}
                  </button>
                </div>

                {/* Context sent to AI */}
                <div style={{ ...S.sec, marginBottom: 18 }}>
                  <div style={S.secTitle}>📋 Context Summary (sent to AI)</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    {[
                      ["Queue Managers", topo.metrics.totalQMs],
                      ["Total Channels", topo.metrics.totalChannels],
                      ["Unused Channels", topo.metrics.unusedChannels],
                      ["Routing Cycles", topo.metrics.cycles],
                      ["Fan Violations", topo.metrics.fanIssues],
                      ["Avg Routing Hops", topo.metrics.avgHops],
                      ["Complexity Score", topo.metrics.complexityScore],
                      ["Health Score", topo.metrics.healthScore],
                    ].map(([k, v]) => (
                      <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: `1px solid ${C.border}` }}>
                        <span style={{ color: C.muted, fontSize: 11 }}>{k}</span>
                        <span style={{ fontWeight: 600, fontSize: 11 }}>{v}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {aiText && (
                  <div style={{ ...S.sec, borderColor: C.violet + "40" }}>
                    <div style={{ ...S.secTitle, color: C.violet }}>✦ AI Analysis Result</div>
                    <div style={{ fontSize: 12, color: C.text, lineHeight: 1.8, whiteSpace: "pre-wrap" }}>{aiText}</div>
                  </div>
                )}
              </div>
            )}

            {/* ─── AGENT PIPELINE ─── */}
            {tab === "agent" && (
              <AgentPipelineTab topo={topo} csvText={topo._csv || SAMPLE_CSV} />
            )}
          </>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// AGENT PIPELINE TAB
// ═══════════════════════════════════════════════════════

// Thin colour palette alias used throughout the Agent tab
const C_AGENT = {
  bg: "#050c18", sur: "#0b1628", sur2: "#0f1e36", border: "#1a2e50",
  accent: "#00d9ff", violet: "#8b5cf6", green: "#10b981", yellow: "#f59e0b",
  red: "#ef4444", blue: "#3b82f6", text: "#dde5f0", muted: "#64748b", orange: "#f97316",
};

const PIPELINE_STEPS = [
  { id: "discovery",    icon: "🔍", label: "Discovery Agent",     desc: "Discover QMs, queues & channels"        },
  { id: "relationship", icon: "🔗", label: "Relationship Agent",  desc: "Map producer / consumer flows"           },
  { id: "anomaly",      icon: "⚠️", label: "Anomaly Detector",    desc: "Surface unused & redundant objects"     },
  { id: "target_state", icon: "🎯", label: "Target State Agent",  desc: "Reason about optimal topology (Gemini 2.5 Flash Lite)" },
  { id: "migration",    icon: "📋", label: "Migration Planner",   desc: "Generate phased migration plan"         },
];

const PHASE_COLORS = { cleanup: C_AGENT.green, structural: C_AGENT.blue, modern: C_AGENT.violet };
const RISK_COLORS  = { LOW: C_AGENT.green, MEDIUM: C_AGENT.yellow, HIGH: C_AGENT.red };
const EFFORT_COLORS = { LOW: C_AGENT.green, MEDIUM: C_AGENT.yellow, HIGH: C_AGENT.orange };

function AgentBadge({ label, color }) {
  return (
    <span style={{
      display: "inline-block", padding: "2px 8px", borderRadius: 4,
      background: color + "22", color, fontSize: 10, fontWeight: 700,
      letterSpacing: "0.05em", whiteSpace: "nowrap",
    }}>{label}</span>
  );
}

function AgentCard({ children, accent }) {
  return (
    <div style={{
      background: C_AGENT.sur2, border: `1px solid ${C_AGENT.border}`,
      borderLeft: `3px solid ${accent || C_AGENT.border}`,
      borderRadius: 10, padding: "16px 18px", marginBottom: 12,
    }}>{children}</div>
  );
}

function AgentSectionTitle({ children, color }) {
  return (
    <div style={{
      fontSize: 11, fontWeight: 700, color: color || C_AGENT.accent,
      textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 14,
    }}>{children}</div>
  );
}

// ── Client-side agent pipeline (mirrors backend logic) ──────────────────────

function runDiscovery(csvText) {
  const lines = csvText.trim().split("\n").filter(l => l.trim());
  const headers = lines[0].split(",").map(h => h.trim().toLowerCase());
  const rows = lines.slice(1).map(line => {
    const vals = line.split(",").map(v => v.trim());
    const row = {};
    headers.forEach((h, i) => row[h] = vals[i] || "");
    row.msg_rate = parseInt(row.msg_rate) || 0;
    row.is_active = row.status?.toUpperCase() === "RUNNING" && row.msg_rate > 0;
    return row;
  }).filter(r => r.source_qm && r.target_qm);

  const qmNames = new Set();
  rows.forEach(r => { qmNames.add(r.source_qm); qmNames.add(r.target_qm); });

  const queueManagers = {};
  qmNames.forEach(qm => {
    const out = rows.filter(r => r.source_qm === qm);
    const inn = rows.filter(r => r.target_qm === qm);
    const apps = [...new Set([...out, ...inn].map(r => r.application).filter(Boolean))];
    queueManagers[qm] = {
      name: qm, outbound_channels: out.length, inbound_channels: inn.length,
      total_traffic: [...out, ...inn].reduce((s, r) => s + r.msg_rate, 0),
      applications: apps, active_channels: [...out, ...inn].filter(r => r.is_active).length,
    };
  });

  const channels = rows.map((r, i) => ({
    id: `e${i}`, name: r.channel_name, type: r.channel_type || "SENDER",
    source_qm: r.source_qm, target_qm: r.target_qm,
    source_queue: r.source_queue || "", target_queue: r.target_queue || "",
    status: r.status || "UNKNOWN", msg_rate: r.msg_rate,
    application: r.application || "", is_active: r.is_active,
    is_unused: !r.is_active, in_cycle: false,
  }));

  const queues = {};
  rows.forEach(r => {
    if (r.source_queue && !queues[r.source_queue])
      queues[r.source_queue] = { name: r.source_queue, qm: r.source_qm, role: "producer", application: r.application };
    if (r.target_queue && !queues[r.target_queue])
      queues[r.target_queue] = { name: r.target_queue, qm: r.target_qm, role: "consumer", application: r.application };
  });

  return {
    queue_managers: queueManagers, channels, queues,
    summary: {
      total_qms: Object.keys(queueManagers).length,
      total_channels: channels.length,
      active_channels: channels.filter(c => c.is_active).length,
      inactive_channels: channels.filter(c => c.is_unused).length,
      total_queues: Object.keys(queues).length,
      applications: [...new Set(rows.map(r => r.application).filter(Boolean))],
      total_daily_msgs: rows.reduce((s, r) => s + r.msg_rate, 0),
    },
  };
}

function runRelationships(inventory) {
  const { channels } = inventory;
  const appFlows = {};
  const producerConsumer = [];
  const qmConn = {};

  channels.filter(c => c.is_active).forEach(ch => {
    const app = ch.application || "Unknown";
    producerConsumer.push({
      producer_qm: ch.source_qm, producer_queue: ch.source_queue,
      consumer_qm: ch.target_qm, consumer_queue: ch.target_queue,
      channel: ch.name, application: app, msg_rate: ch.msg_rate,
    });
    appFlows[app] = appFlows[app] || [];
    appFlows[app].push(`${ch.source_qm}.${ch.source_queue} → ${ch.target_qm}.${ch.target_queue}`);

    [ch.source_qm, ch.target_qm].forEach(qm => {
      qmConn[qm] = qmConn[qm] || { in: 0, out: 0, traffic: 0 };
    });
    qmConn[ch.source_qm].out++;
    qmConn[ch.target_qm].in++;
    qmConn[ch.source_qm].traffic += ch.msg_rate;
    qmConn[ch.target_qm].traffic += ch.msg_rate;
  });

  const hubs = Object.entries(qmConn)
    .map(([qm, v]) => ({ qm, in_degree: v.in, out_degree: v.out, total_traffic: v.traffic, is_hub: v.in + v.out >= 4 }))
    .sort((a, b) => (b.in_degree + b.out_degree) - (a.in_degree + a.out_degree));

  return {
    producer_consumer: producerConsumer, application_flows: appFlows,
    connectivity: qmConn, hubs,
    critical_paths: [...producerConsumer].sort((a, b) => b.msg_rate - a.msg_rate).slice(0, 5),
    total_daily_msgs: channels.reduce((s, c) => s + c.msg_rate, 0),
  };
}

function runAnomalies(inventory) {
  const { channels } = inventory;
  const qms = Object.keys(inventory.queue_managers);
  const anomalies = [];

  // Unused
  channels.filter(c => c.is_unused).forEach(ch => {
    anomalies.push({
      type: "UNUSED_CHANNEL", severity: "MEDIUM", object: ch.name,
      detail: `${ch.name} (${ch.source_qm} → ${ch.target_qm}) — ${ch.status}, ${ch.msg_rate} msg/day`,
      recommendation: "Decommission after confirming no planned reuse",
      impact: "Reduces attack surface and config sprawl", weak_link: null,
    });
  });

  // Cycles (DFS)
  const adj = {};
  qms.forEach(qm => adj[qm] = []);
  channels.filter(c => c.is_active).forEach(ch => {
    adj[ch.source_qm]?.push([ch.target_qm, ch.name, ch.msg_rate]);
  });
  const WHITE = 0, GRAY = 1, BLACK = 2;
  const color = {};
  qms.forEach(qm => color[qm] = WHITE);
  const path = [];
  const foundKeys = new Set();

  function dfs(u) {
    color[u] = GRAY; path.push(u);
    (adj[u] || []).forEach(([v, chName, rate]) => {
      if (color[v] === GRAY) {
        const start = path.indexOf(v);
        const cycle = [...path.slice(start), v];
        const key = [...cycle.slice(0, -1)].sort().join(",");
        if (!foundKeys.has(key)) {
          foundKeys.add(key);
          const cycleEdges = [];
          for (let i = 0; i < cycle.length - 1; i++) {
            const e = channels.find(c => c.is_active && c.source_qm === cycle[i] && c.target_qm === cycle[i + 1]);
            if (e) { cycleEdges.push(e); e.in_cycle = true; }
          }
          const minE = cycleEdges.reduce((m, e) => e.msg_rate < m.msg_rate ? e : m, cycleEdges[0] || null);
          anomalies.push({
            type: "ROUTING_CYCLE", severity: "CRITICAL",
            object: cycle.slice(0, -1).join(" → "),
            detail: `Circular routing: ${cycle.slice(0, -1).join(" → ")} ↻ (${cycle.length - 1} hops)`,
            recommendation: `Break cycle — remove ${minE?.name || "lowest-traffic edge"} (${minE?.msg_rate || 0} msg/day)`,
            impact: "Eliminates message storm risk and unbounded queue growth",
            weak_link: minE?.name || null,
          });
        }
      } else if (color[v] === WHITE) dfs(v);
    });
    path.pop(); color[u] = BLACK;
  }
  qms.forEach(qm => { if (color[qm] === WHITE) dfs(qm); });

  // Fan-in / Fan-out
  const inDeg = {}, outDeg = {};
  channels.filter(c => c.is_active).forEach(ch => {
    inDeg[ch.target_qm] = (inDeg[ch.target_qm] || 0) + 1;
    outDeg[ch.source_qm] = (outDeg[ch.source_qm] || 0) + 1;
  });
  Object.entries(inDeg).filter(([, d]) => d > 3).forEach(([qm, d]) => {
    const sources = channels.filter(c => c.is_active && c.target_qm === qm).map(c => c.source_qm);
    anomalies.push({
      type: "FAN_IN", severity: "MEDIUM", object: qm,
      detail: `${qm} receives from ${d} sources: ${sources.join(", ")}`,
      recommendation: `Introduce aggregator QM upstream of ${qm}`,
      impact: `Reduces incoming connections from ${d} to 1`, weak_link: null,
    });
  });
  Object.entries(outDeg).filter(([, d]) => d > 3).forEach(([qm, d]) => {
    const targets = channels.filter(c => c.is_active && c.source_qm === qm).map(c => c.target_qm);
    anomalies.push({
      type: "FAN_OUT", severity: "MEDIUM", object: qm,
      detail: `${qm} dispatches to ${d} targets: ${targets.join(", ")}`,
      recommendation: `Apply pub/sub topic routing at ${qm}`,
      impact: "Decouples producers from consumers", weak_link: null,
    });
  });

  return anomalies;
}

async function runTargetStateAgent(inventory, relationships, anomalies) {
  const channels = inventory.channels;
  const context = {
    summary: inventory.summary, anomalies,
    hubs: relationships.hubs,
    critical_paths: relationships.critical_paths,
    application_flows: Object.fromEntries(Object.entries(relationships.application_flows).slice(0, 8)),
  };

  const prompt = `You are a senior IBM MQ architect. Analyse this topology and define the ideal target state.

CURRENT TOPOLOGY:
${JSON.stringify(context, null, 2)}

ACTIVE CHANNELS:
${JSON.stringify(channels.filter(c => c.is_active), null, 2)}

Return ONLY a valid JSON object (no markdown) with this schema:
{
  "architecture_pattern": "hub-spoke | mesh | pipeline | hybrid",
  "pattern_rationale": "2-3 sentence rationale",
  "target_qms": [{ "name": "QM_NAME", "role": "hub|spoke|gateway|aggregator|archive|decommission", "keep": true, "reason": "one sentence" }],
  "target_channels": [{ "action": "keep|remove|add|modify", "channel_name": "CHAN.NAME", "source_qm": "QM_A", "target_qm": "QM_B", "reason": "one sentence" }],
  "key_decisions": [{ "decision": "short title", "rationale": "2-3 sentence WHY explanation", "trade_offs": "what is given up", "priority": "immediate|short-term|long-term" }]
}`;

  const GEMINI_API_KEY = window.__GEMINI_API_KEY__ || "";
  const geminiEndpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=${GEMINI_API_KEY}`;
  const fullPrompt = `You are a senior IBM MQ architect. Respond only with valid JSON — no markdown, no preamble.\n\n${prompt}`;

  const res = await fetch(geminiEndpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: fullPrompt }] }],
      generationConfig: { maxOutputTokens: 2048, temperature: 0.2 },
    }),
  });
  const data = await res.json();
  let raw = data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || "{}";
  if (raw.startsWith("```")) { raw = raw.split("```")[1]; if (raw.startsWith("json")) raw = raw.slice(4); }

  let parsed = {};
  try { parsed = JSON.parse(raw.trim()); } catch (_) {
    parsed = {
      architecture_pattern: "hub-spoke",
      pattern_rationale: "Based on traffic analysis, a hub-spoke pattern best fits this topology.",
      target_qms: [], target_channels: [],
      key_decisions: [
        { decision: "Remove unused channels", rationale: "Channels with zero traffic increase config sprawl and attack surface.", trade_offs: "None — channels carry no traffic.", priority: "immediate" },
        { decision: "Break routing cycles", rationale: "Circular routes risk unbounded message amplification.", trade_offs: "Application routing logic must be updated.", priority: "immediate" },
      ],
    };
  }

  const removedByLLM = new Set((parsed.target_channels || []).filter(tc => tc.action === "remove").map(tc => tc.channel_name));
  const keepChannels = channels.filter(c => c.is_active && !removedByLLM.has(c.name));
  const nodeIds = new Set(keepChannels.flatMap(c => [c.source_qm, c.target_qm]));

  return {
    architecture_pattern: parsed.architecture_pattern || "hub-spoke",
    pattern_rationale: parsed.pattern_rationale || "",
    target_qms: parsed.target_qms || [],
    target_channels: parsed.target_channels || [],
    key_decisions: parsed.key_decisions || [],
    optimized_edges: keepChannels,
    optimized_nodes: [...nodeIds].map(qm => ({
      id: qm,
      role: (parsed.target_qms || []).find(t => t.name === qm)?.role || "spoke",
      ...inventory.queue_managers[qm],
    })),
    removed_channels: [...removedByLLM, ...channels.filter(c => c.is_unused).map(c => c.name)],
    metrics: {
      original_channels: channels.length,
      target_channels: keepChannels.length,
      channels_removed: channels.length - keepChannels.length,
      original_qms: Object.keys(inventory.queue_managers).length,
      target_qms_count: nodeIds.size,
    },
  };
}

function buildMigrationPlan(anomalies, targetState, decisions) {
  const steps = [];
  let n = 1;

  const unused = anomalies.filter(a => a.type === "UNUSED_CHANNEL");
  if (unused.length) {
    steps.push({
      step: n++, phase: "Phase 1 — Cleanup", phase_key: "cleanup",
      title: `Decommission ${unused.length} unused channel(s)`,
      actions: unused.map(a => `Stop and delete ${a.object}`),
      risk: "LOW", effort: "LOW", duration: "1–2 days",
      validation: "Zero traffic on each channel for ≥ 30 days",
      rollback: "Re-create from MQSC backup",
    });
  }

  anomalies.filter(a => a.type === "ROUTING_CYCLE").forEach(ca => {
    steps.push({
      step: n++, phase: "Phase 1 — Cleanup", phase_key: "cleanup",
      title: `Break routing cycle: ${ca.object.slice(0, 55)}`,
      actions: [
        `Identify application owning ${ca.weak_link || "cycle channel"}`,
        "Replace sync response with async event/callback",
        `Disable ${ca.weak_link || "cycle channel"}`,
        "Monitor queues for 24 h post-change",
      ],
      risk: "HIGH", effort: "MEDIUM", duration: "3–5 days",
      validation: "No message accumulation in any cycle queue",
      rollback: "Re-enable channel and revert routing config",
    });
  });

  anomalies.filter(a => a.type === "FAN_IN").forEach(fa => {
    const agg = `QM_AGG_${fa.object.replace("QM_", "")}`;
    steps.push({
      step: n++, phase: "Phase 2 — Structural", phase_key: "structural",
      title: `Introduce aggregator upstream of ${fa.object}`,
      actions: [
        `Provision aggregator QM: ${agg}`,
        `Route all senders → ${agg}`,
        `Define single channel: ${agg} → ${fa.object}`,
        "Migrate applications to target the aggregator",
        "Decommission direct channels once stable",
      ],
      risk: "MEDIUM", effort: "HIGH", duration: "1–2 weeks",
      validation: "All traffic via aggregator, zero message loss",
      rollback: "Keep parallel direct channels until validated",
    });
  });

  anomalies.filter(a => a.type === "FAN_OUT").forEach(fo => {
    steps.push({
      step: n++, phase: "Phase 2 — Structural", phase_key: "structural",
      title: `Implement pub/sub routing at ${fo.object}`,
      actions: [
        `Define topic-based routing on ${fo.object}`,
        "Subscribe downstream QMs to topics",
        "Remove point-to-point channels",
        "Update application routing config",
      ],
      risk: "MEDIUM", effort: "HIGH", duration: "1–2 weeks",
      validation: "All consumers receiving via topic subscriptions",
      rollback: "Re-enable point-to-point channels",
    });
  });

  (decisions || []).filter(d => d.priority === "long-term").forEach(dec => {
    steps.push({
      step: n++, phase: "Phase 3 — Modernisation", phase_key: "modern",
      title: dec.decision,
      actions: [dec.rationale, `Trade-offs: ${dec.trade_offs || "N/A"}`],
      risk: "LOW", effort: "HIGH", duration: "4–8 weeks",
      validation: "Architecture review sign-off + integration tests pass",
      rollback: "Revert to prior topology version",
    });
  });

  steps.push({
    step: n, phase: "Phase 3 — Modernisation", phase_key: "modern",
    title: "Implement topology observability & drift alerting",
    actions: [
      "Deploy channel monitoring with dead-letter alerting",
      "Automate complexity score tracking in CI pipeline",
      "Configure alerts for new STOPPED channels",
      "Schedule quarterly topology review",
    ],
    risk: "LOW", effort: "MEDIUM", duration: "2–3 weeks",
    validation: "Dashboard live — all QMs reporting",
    rollback: "N/A",
  });

  return steps;
}

// ── Sub-component: ForceGraph (reused from main) ─────────────────────────────
// (already defined above as ForceGraph — no redeclaration needed)

// ── Main Agent Pipeline Tab Component ───────────────────────────────────────
function AgentPipelineTab({ topo, csvText }) {
  const [running,    setRunning]    = useState(false);
  const [stepIdx,    setStepIdx]    = useState(-1);    // -1 = idle
  const [agentData,  setAgentData]  = useState(null);
  const [logs,       setLogs]       = useState([]);
  const [subTab,     setSubTab]     = useState("inventory");
  const logRef = useRef(null);

  const addLog = (msg) => setLogs(prev => [...prev, msg]);

  const delay = (ms) => new Promise(r => setTimeout(r, ms));

  const runPipeline = async () => {
    setRunning(true);
    setAgentData(null);
    setLogs([]);
    setStepIdx(0);

    try {
      // Step 0 — Discovery
      addLog("🔍 Discovery Agent: Parsing MQ topology from CSV…");
      await delay(400);
      const inventory = runDiscovery(csvText);
      addLog(`✅ Discovered ${inventory.summary.total_qms} QMs · ${inventory.summary.total_channels} channels · ${inventory.summary.total_queues} queues`);
      setStepIdx(1);

      // Step 1 — Relationships
      addLog("🔗 Relationship Agent: Mapping producer/consumer dependencies…");
      await delay(400);
      const relationships = runRelationships(inventory);
      const hubCount = relationships.hubs.filter(h => h.is_hub).length;
      addLog(`✅ Mapped ${relationships.producer_consumer.length} flows · ${Object.keys(relationships.application_flows).length} apps · ${hubCount} hub QMs`);
      setStepIdx(2);

      // Step 2 — Anomalies
      addLog("⚠️  Anomaly Detector: Scanning for issues and anti-patterns…");
      await delay(400);
      const anomalies = runAnomalies(inventory);
      const crit = anomalies.filter(a => a.severity === "CRITICAL").length;
      const med  = anomalies.filter(a => a.severity === "MEDIUM").length;
      addLog(`✅ Found ${anomalies.length} issues (${crit} critical · ${med} medium)`);
      setStepIdx(3);

      // Step 3 — Target State (Gemini 2.5 Flash Lite)
      addLog("🎯 Target State Agent: Reasoning about optimal topology with Gemini 2.5 Flash Lite…");
      const targetState = await runTargetStateAgent(inventory, relationships, anomalies);
      addLog(`✅ Target state defined — ${targetState.architecture_pattern} pattern · ${targetState.metrics.target_channels} channels retained`);
      setStepIdx(4);

      // Step 4 — Migration Plan
      addLog("📋 Migration Planner: Generating phased migration plan…");
      await delay(300);
      const plan = buildMigrationPlan(anomalies, targetState, targetState.key_decisions);
      const phases = [...new Set(plan.map(s => s.phase))].length;
      addLog(`✅ Migration plan — ${plan.length} steps across ${phases} phases`);
      addLog("🎉 All 5 agents finished successfully.");
      setStepIdx(5);

      setAgentData({ inventory, relationships, anomalies, targetState, decisions: targetState.key_decisions, migrationPlan: plan });
    } catch (e) {
      addLog(`❌ Pipeline error: ${e.message}`);
    } finally {
      setRunning(false);
    }
  };

  // Auto-scroll log
  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [logs]);

  const font = "'JetBrains Mono','Courier New',monospace";

  const exportJSON = () => {
    if (!agentData) return;
    const blob = new Blob([JSON.stringify(agentData, null, 2)], { type: "application/json" });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a"); a.href = url; a.download = "mqoptima_report.json"; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      {/* Pipeline header */}
      <div style={{ background: "linear-gradient(135deg,#0b1628,#0f1e36)", border: `1px solid #1a2e50`, borderRadius: 14, padding: "20px 24px", marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, letterSpacing: "-0.01em", marginBottom: 5 }}>
              ⬡ Intelligent MQ Inventory <span style={{ color: C_AGENT.accent }}>&amp;</span> Target State Agent
            </div>
            <div style={{ fontSize: 11, color: C_AGENT.muted, lineHeight: 1.6 }}>
              5-agent LangGraph pipeline · Discovers topology · Maps relationships · Surfaces anomalies · Reasons about target state with Gemini 2.5 Flash Lite · Generates migration plan
            </div>
          </div>
          <button
            onClick={runPipeline}
            disabled={running}
            style={{
              padding: "10px 26px", fontFamily: font, fontSize: 12, fontWeight: 700,
              cursor: running ? "wait" : "pointer",
              background: running ? C_AGENT.sur2 : `linear-gradient(135deg, ${C_AGENT.accent}33, ${C_AGENT.violet}55)`,
              border: `1px solid ${running ? C_AGENT.border : C_AGENT.accent}`,
              borderRadius: 9, color: running ? C_AGENT.muted : C_AGENT.accent,
              letterSpacing: "0.04em", transition: "all 0.2s",
            }}
          >
            {running ? "⚙ Running Pipeline…" : agentData ? "↺ Re-run Pipeline" : "▶ Run Agent Pipeline"}
          </button>
        </div>

        {/* Step tracker */}
        <div style={{ display: "flex", gap: 0, marginTop: 20, overflowX: "auto" }}>
          {PIPELINE_STEPS.map((step, i) => {
            const done    = stepIdx > i;
            const active  = stepIdx === i;
            const pending = stepIdx < i;
            return (
              <div key={step.id} style={{ display: "flex", alignItems: "center", flex: 1, minWidth: 140 }}>
                <div style={{
                  flex: 1, padding: "10px 12px", borderRadius: 8,
                  background: done ? C_AGENT.green + "15" : active ? C_AGENT.accent + "15" : C_AGENT.sur2,
                  border: `1px solid ${done ? C_AGENT.green + "60" : active ? C_AGENT.accent + "60" : C_AGENT.border}`,
                  opacity: pending && stepIdx >= 0 ? 0.5 : 1, transition: "all 0.3s",
                }}>
                  <div style={{ fontSize: 16, marginBottom: 4 }}>
                    {done ? "✅" : active ? "⚙" : step.icon}
                  </div>
                  <div style={{ fontSize: 10, fontWeight: 700, color: done ? C_AGENT.green : active ? C_AGENT.accent : C_AGENT.muted }}>
                    {step.label}
                  </div>
                  <div style={{ fontSize: 9, color: C_AGENT.muted, marginTop: 2, lineHeight: 1.4 }}>{step.desc}</div>
                </div>
                {i < PIPELINE_STEPS.length - 1 && (
                  <div style={{ width: 16, height: 1, background: done ? C_AGENT.green + "60" : C_AGENT.border, flexShrink: 0 }} />
                )}
              </div>
            );
          })}
        </div>

        {/* Log output */}
        {logs.length > 0 && (
          <div ref={logRef} style={{
            marginTop: 16, background: "#020810", border: `1px solid ${C_AGENT.border}`,
            borderRadius: 8, padding: "12px 14px", maxHeight: 120, overflowY: "auto",
            fontFamily: font, fontSize: 11, color: C_AGENT.muted, lineHeight: 1.8,
          }}>
            {logs.map((l, i) => <div key={i} style={{ color: l.startsWith("✅") ? C_AGENT.green : l.startsWith("❌") ? C_AGENT.red : l.startsWith("🎉") ? C_AGENT.accent : C_AGENT.muted }}>{l}</div>)}
          </div>
        )}
      </div>

      {/* Results */}
      {agentData && (() => {
        const { inventory, relationships, anomalies, targetState, decisions, migrationPlan } = agentData;
        const AGENT_SUB_TABS = ["inventory", "relationships", "anomalies", "before-after", "decisions", "migration", "export"];
        const AGENT_SUB_LABELS = ["Inventory", "Relationships", "Anomalies", "Before → After", "Decisions Explained", "Migration Plan", "Export"];

        return (
          <>
            {/* Sub-tab bar */}
            <div style={{ display: "flex", gap: 4, padding: 4, background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 10, marginBottom: 20, overflowX: "auto" }}>
              {AGENT_SUB_TABS.map((id, i) => (
                <button key={id} onClick={() => setSubTab(id)} style={{
                  padding: "7px 14px", borderRadius: 7, fontFamily: font, fontSize: 11, whiteSpace: "nowrap",
                  cursor: "pointer", fontWeight: subTab === id ? 700 : 400,
                  color: subTab === id ? C_AGENT.accent : C_AGENT.muted,
                  background: subTab === id ? C_AGENT.sur2 : "transparent",
                  border: subTab === id ? `1px solid ${C_AGENT.border}` : "1px solid transparent",
                }}>{AGENT_SUB_LABELS[i]}</button>
              ))}
            </div>

            {/* ── INVENTORY ── */}
            {subTab === "inventory" && (
              <>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 12, marginBottom: 18 }}>
                  {[
                    { label: "Queue Managers", val: inventory.summary.total_qms,        c: C_AGENT.blue },
                    { label: "Total Channels",  val: inventory.summary.total_channels,   c: C_AGENT.accent },
                    { label: "Active Channels", val: inventory.summary.active_channels,  c: C_AGENT.green },
                    { label: "Inactive",        val: inventory.summary.inactive_channels,c: C_AGENT.red },
                    { label: "Queues",          val: inventory.summary.total_queues,     c: C_AGENT.violet },
                    { label: "Applications",    val: inventory.summary.applications.length, c: C_AGENT.orange },
                    { label: "Daily Messages",  val: inventory.summary.total_daily_msgs.toLocaleString(), c: C_AGENT.yellow },
                  ].map(m => (
                    <div key={m.label} style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderLeft: `3px solid ${m.c}`, borderRadius: 10, padding: "16px 18px" }}>
                      <div style={{ fontSize: 28, fontWeight: 700, color: m.c, lineHeight: 1 }}>{m.val}</div>
                      <div style={{ fontSize: 10, color: C_AGENT.muted, marginTop: 6, textTransform: "uppercase", letterSpacing: "0.06em" }}>{m.label}</div>
                    </div>
                  ))}
                </div>

                <div style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 12, padding: "18px 20px", marginBottom: 16 }}>
                  <AgentSectionTitle>📦 Queue Manager Inventory</AgentSectionTitle>
                  <div style={{ overflowX: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
                      <thead>
                        <tr style={{ borderBottom: `1px solid ${C_AGENT.border}` }}>
                          {["Queue Manager", "Outbound", "Inbound", "Active Ch.", "Traffic (msg/day)", "Applications"].map(h => (
                            <th key={h} style={{ padding: "8px 12px", textAlign: "left", color: C_AGENT.muted, fontWeight: 600, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em", whiteSpace: "nowrap" }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {Object.values(inventory.queue_managers).sort((a, b) => b.total_traffic - a.total_traffic).map(qm => (
                          <tr key={qm.name} style={{ borderBottom: `1px solid ${C_AGENT.border}20` }}>
                            <td style={{ padding: "9px 12px", fontWeight: 700, color: C_AGENT.accent }}>{qm.name}</td>
                            <td style={{ padding: "9px 12px", color: C_AGENT.text }}>{qm.outbound_channels}</td>
                            <td style={{ padding: "9px 12px", color: C_AGENT.text }}>{qm.inbound_channels}</td>
                            <td style={{ padding: "9px 12px", color: C_AGENT.green }}>{qm.active_channels}</td>
                            <td style={{ padding: "9px 12px", color: C_AGENT.yellow }}>{qm.total_traffic.toLocaleString()}</td>
                            <td style={{ padding: "9px 12px", color: C_AGENT.muted, fontSize: 10 }}>{qm.applications.join(", ") || "—"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 12, padding: "18px 20px" }}>
                  <AgentSectionTitle>📡 Channel Inventory ({inventory.channels.length})</AgentSectionTitle>
                  <div style={{ overflowX: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
                      <thead>
                        <tr style={{ borderBottom: `1px solid ${C_AGENT.border}` }}>
                          {["Channel", "Source QM", "Target QM", "Status", "Traffic", "Application"].map(h => (
                            <th key={h} style={{ padding: "8px 12px", textAlign: "left", color: C_AGENT.muted, fontWeight: 600, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.06em", whiteSpace: "nowrap" }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {inventory.channels.map(ch => (
                          <tr key={ch.name} style={{ borderBottom: `1px solid ${C_AGENT.border}15`, opacity: ch.is_unused ? 0.55 : 1 }}>
                            <td style={{ padding: "8px 12px", fontWeight: 600, color: ch.in_cycle ? C_AGENT.red : C_AGENT.text }}>{ch.name}{ch.in_cycle ? " ↻" : ""}</td>
                            <td style={{ padding: "8px 12px", color: C_AGENT.muted }}>{ch.source_qm}</td>
                            <td style={{ padding: "8px 12px", color: C_AGENT.muted }}>{ch.target_qm}</td>
                            <td style={{ padding: "8px 12px" }}>
                              <span style={{ display: "inline-block", padding: "2px 7px", borderRadius: 4, fontSize: 9, fontWeight: 700, background: ch.is_active ? C_AGENT.green + "22" : C_AGENT.red + "22", color: ch.is_active ? C_AGENT.green : C_AGENT.red }}>
                                {ch.status}
                              </span>
                            </td>
                            <td style={{ padding: "8px 12px", color: C_AGENT.yellow }}>{ch.msg_rate.toLocaleString()}</td>
                            <td style={{ padding: "8px 12px", color: C_AGENT.muted, fontSize: 10 }}>{ch.application || "—"}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}

            {/* ── RELATIONSHIPS ── */}
            {subTab === "relationships" && (
              <>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
                  <div style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 12, padding: "18px 20px" }}>
                    <AgentSectionTitle>🏭 Hub Queue Managers</AgentSectionTitle>
                    {relationships.hubs.slice(0, 8).map(h => (
                      <div key={h.qm} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 0", borderBottom: `1px solid ${C_AGENT.border}20` }}>
                        <div>
                          <span style={{ fontWeight: 700, color: h.is_hub ? C_AGENT.yellow : C_AGENT.text }}>{h.qm}</span>
                          {h.is_hub && <span style={{ marginLeft: 8, fontSize: 9, color: C_AGENT.yellow, fontWeight: 700 }}>HUB</span>}
                        </div>
                        <div style={{ display: "flex", gap: 12, fontSize: 11 }}>
                          <span style={{ color: C_AGENT.blue }}>↓{h.in_degree} in</span>
                          <span style={{ color: C_AGENT.green }}>↑{h.out_degree} out</span>
                          <span style={{ color: C_AGENT.muted }}>{h.total_traffic.toLocaleString()} msg/d</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 12, padding: "18px 20px" }}>
                    <AgentSectionTitle>🔥 Critical Paths (Top 5 by Traffic)</AgentSectionTitle>
                    {relationships.critical_paths.map((cp, i) => (
                      <div key={i} style={{ padding: "9px 0", borderBottom: `1px solid ${C_AGENT.border}20` }}>
                        <div style={{ fontSize: 11, fontWeight: 600, marginBottom: 3 }}>
                          {cp.producer_qm} → {cp.consumer_qm}
                        </div>
                        <div style={{ display: "flex", gap: 10, fontSize: 10, color: C_AGENT.muted }}>
                          <span style={{ color: C_AGENT.yellow }}>{cp.msg_rate.toLocaleString()} msg/day</span>
                          <span>{cp.channel}</span>
                          <span>{cp.application}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 12, padding: "18px 20px" }}>
                  <AgentSectionTitle>🔄 Producer → Consumer Map ({relationships.producer_consumer.length} flows)</AgentSectionTitle>
                  <div style={{ overflowX: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
                      <thead>
                        <tr style={{ borderBottom: `1px solid ${C_AGENT.border}` }}>
                          {["Producer QM", "Producer Queue", "Consumer QM", "Consumer Queue", "Application", "Traffic"].map(h => (
                            <th key={h} style={{ padding: "7px 10px", textAlign: "left", color: C_AGENT.muted, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.05em", whiteSpace: "nowrap" }}>{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {relationships.producer_consumer.slice(0, 20).map((pc, i) => (
                          <tr key={i} style={{ borderBottom: `1px solid ${C_AGENT.border}15` }}>
                            <td style={{ padding: "7px 10px", color: C_AGENT.blue, fontWeight: 600 }}>{pc.producer_qm}</td>
                            <td style={{ padding: "7px 10px", color: C_AGENT.muted, fontSize: 10 }}>{pc.producer_queue}</td>
                            <td style={{ padding: "7px 10px", color: C_AGENT.green, fontWeight: 600 }}>{pc.consumer_qm}</td>
                            <td style={{ padding: "7px 10px", color: C_AGENT.muted, fontSize: 10 }}>{pc.consumer_queue}</td>
                            <td style={{ padding: "7px 10px", color: C_AGENT.muted }}>{pc.application}</td>
                            <td style={{ padding: "7px 10px", color: C_AGENT.yellow }}>{pc.msg_rate.toLocaleString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}

            {/* ── ANOMALIES ── */}
            {subTab === "anomalies" && (
              <>
                <div style={{ display: "flex", gap: 12, marginBottom: 18 }}>
                  {[
                    { label: "Critical", count: anomalies.filter(a => a.severity === "CRITICAL").length, c: C_AGENT.red },
                    { label: "Medium",   count: anomalies.filter(a => a.severity === "MEDIUM").length,   c: C_AGENT.yellow },
                    { label: "Low",      count: anomalies.filter(a => a.severity === "LOW").length,      c: C_AGENT.blue },
                  ].map(s => (
                    <div key={s.label} style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderLeft: `3px solid ${s.c}`, borderRadius: 10, padding: "14px 18px", flex: 1 }}>
                      <div style={{ fontSize: 28, fontWeight: 700, color: s.c }}>{s.count}</div>
                      <div style={{ fontSize: 10, color: C_AGENT.muted, marginTop: 5, textTransform: "uppercase" }}>{s.label} Severity</div>
                    </div>
                  ))}
                </div>
                {anomalies.length === 0 ? (
                  <div style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 12, padding: 24, textAlign: "center", color: C_AGENT.green }}>✅ No anomalies detected — topology is clean!</div>
                ) : anomalies.map((a, i) => {
                  const sevColor = a.severity === "CRITICAL" ? C_AGENT.red : a.severity === "MEDIUM" ? C_AGENT.yellow : C_AGENT.blue;
                  const typeLabels = { ROUTING_CYCLE: "CYCLE", UNUSED_CHANNEL: "UNUSED", FAN_IN: "FAN-IN", FAN_OUT: "FAN-OUT", REDUNDANT_CHANNELS: "REDUNDANT" };
                  return (
                    <div key={i} style={{ display: "flex", gap: 12, padding: "13px 15px", background: C_AGENT.sur2, borderRadius: 9, marginBottom: 10, borderLeft: `3px solid ${sevColor}` }}>
                      <div style={{ paddingTop: 1, flexShrink: 0 }}>
                        <AgentBadge label={typeLabels[a.type] || a.type} color={sevColor} />
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 700, marginBottom: 5, fontSize: 13 }}>{a.object}</div>
                        <div style={{ fontSize: 11, color: C_AGENT.muted, marginBottom: 6, lineHeight: 1.6 }}>{a.detail}</div>
                        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                          <div style={{ fontSize: 11, color: C_AGENT.accent }}>→ {a.recommendation}</div>
                          {a.weak_link && <div style={{ fontSize: 10, color: C_AGENT.yellow }}>⚡ Break point: {a.weak_link}</div>}
                        </div>
                        <div style={{ marginTop: 6, fontSize: 11, color: C_AGENT.green, background: C_AGENT.green + "0f", padding: "5px 10px", borderRadius: 6, display: "inline-block" }}>↑ {a.impact}</div>
                      </div>
                    </div>
                  );
                })}
              </>
            )}

            {/* ── BEFORE → AFTER ── */}
            {subTab === "before-after" && (
              <>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 12, marginBottom: 18 }}>
                  {[
                    { label: "Channels Removed",  val: `−${targetState.metrics.channels_removed}`, c: C_AGENT.green },
                    { label: "Target Channels",    val: targetState.metrics.target_channels,         c: C_AGENT.accent },
                    { label: "Target QMs",         val: targetState.metrics.target_qms_count,        c: C_AGENT.blue },
                    { label: "Architecture",       val: targetState.architecture_pattern,            c: C_AGENT.violet },
                  ].map(m => (
                    <div key={m.label} style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderLeft: `3px solid ${m.c}`, borderRadius: 10, padding: "16px 18px" }}>
                      <div style={{ fontSize: 22, fontWeight: 700, color: m.c, lineHeight: 1 }}>{m.val}</div>
                      <div style={{ fontSize: 10, color: C_AGENT.muted, marginTop: 6, textTransform: "uppercase" }}>{m.label}</div>
                    </div>
                  ))}
                </div>

                {targetState.pattern_rationale && (
                  <div style={{ background: C_AGENT.sur2, border: `1px solid ${C_AGENT.violet}30`, borderRadius: 10, padding: "12px 16px", marginBottom: 18, fontSize: 12, color: C_AGENT.text, lineHeight: 1.7 }}>
                    <span style={{ color: C_AGENT.violet, fontWeight: 700 }}>Pattern rationale: </span>{targetState.pattern_rationale}
                  </div>
                )}

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  <div style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 12, padding: "18px 20px" }}>
                    <AgentSectionTitle color={C_AGENT.red}>⚠️ Current Topology — {inventory.channels.length} channels</AgentSectionTitle>
                    <ForceGraph nodes={Object.values(inventory.queue_managers).map(qm => ({ id: qm.name, totalTraffic: qm.total_traffic, inDegree: qm.inbound_channels, outDegree: qm.outbound_channels }))} edges={inventory.channels} height={380} />
                  </div>
                  <div style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 12, padding: "18px 20px" }}>
                    <AgentSectionTitle color={C_AGENT.green}>✅ Target Topology — {targetState.metrics.target_channels} channels</AgentSectionTitle>
                    <ForceGraph nodes={targetState.optimized_nodes.map(n => ({ id: n.id, totalTraffic: n.total_traffic || 0, inDegree: n.inbound_channels || 0, outDegree: n.outbound_channels || 0 }))} edges={targetState.optimized_edges} height={380} />
                  </div>
                </div>
              </>
            )}

            {/* ── DECISIONS EXPLAINED ── */}
            {subTab === "decisions" && (
              <>
                <div style={{ background: C_AGENT.sur2, border: `1px solid ${C_AGENT.violet}30`, borderRadius: 10, padding: "14px 18px", marginBottom: 20, fontSize: 12, color: C_AGENT.text, lineHeight: 1.7 }}>
                  <span style={{ color: C_AGENT.violet, fontWeight: 700 }}>Architecture pattern: </span>
                  <span style={{ color: C_AGENT.accent, fontWeight: 700 }}>{targetState.architecture_pattern}</span>
                  {targetState.pattern_rationale && <span> — {targetState.pattern_rationale}</span>}
                </div>

                {(decisions || []).length === 0 ? (
                  <div style={{ color: C_AGENT.muted, padding: 20, textAlign: "center" }}>No decisions available yet. Run the pipeline first.</div>
                ) : (decisions || []).map((dec, i) => {
                  const priColor = { immediate: C_AGENT.red, "short-term": C_AGENT.yellow, "long-term": C_AGENT.blue };
                  const c = priColor[dec.priority] || C_AGENT.muted;
                  return (
                    <div key={i} style={{ background: C_AGENT.sur2, borderRadius: 10, padding: "16px 18px", marginBottom: 14, border: `1px solid ${c}25` }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10, gap: 10, flexWrap: "wrap" }}>
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <span style={{ fontSize: 10, color: C_AGENT.muted }}>D{String(i + 1).padStart(2, "0")}</span>
                          <AgentBadge label={dec.priority?.toUpperCase() || "MEDIUM"} color={c} />
                        </div>
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8, color: C_AGENT.text }}>{dec.decision}</div>
                      <div style={{ fontSize: 11, color: C_AGENT.muted, marginBottom: 10, lineHeight: 1.7 }}>
                        <span style={{ color: C_AGENT.accent, fontWeight: 700 }}>Why: </span>{dec.rationale}
                      </div>
                      {dec.trade_offs && (
                        <div style={{ fontSize: 11, color: C_AGENT.yellow, background: C_AGENT.yellow + "0d", padding: "7px 12px", borderRadius: 6 }}>
                          ⚖️ Trade-offs: {dec.trade_offs}
                        </div>
                      )}
                    </div>
                  );
                })}
              </>
            )}

            {/* ── MIGRATION PLAN ── */}
            {subTab === "migration" && (
              <>
                <div style={{ display: "flex", gap: 12, marginBottom: 18 }}>
                  {[
                    { label: "Phase 1 — Cleanup",        key: "cleanup",    c: C_AGENT.green },
                    { label: "Phase 2 — Structural",     key: "structural", c: C_AGENT.blue },
                    { label: "Phase 3 — Modernisation",  key: "modern",     c: C_AGENT.violet },
                  ].map(ph => {
                    const count = migrationPlan.filter(s => s.phase_key === ph.key).length;
                    return (
                      <div key={ph.key} style={{ flex: 1, background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderLeft: `3px solid ${ph.c}`, borderRadius: 10, padding: "14px 18px" }}>
                        <div style={{ fontSize: 22, fontWeight: 700, color: ph.c }}>{count}</div>
                        <div style={{ fontSize: 10, color: C_AGENT.muted, marginTop: 5, textTransform: "uppercase" }}>{ph.label}</div>
                      </div>
                    );
                  })}
                </div>

                {migrationPlan.map(step => {
                  const phColor = { cleanup: C_AGENT.green, structural: C_AGENT.blue, modern: C_AGENT.violet }[step.phase_key] || C_AGENT.muted;
                  return (
                    <div key={step.step} style={{ background: C_AGENT.sur2, borderRadius: 10, padding: "16px 18px", marginBottom: 14, border: `1px solid ${phColor}20` }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10, flexWrap: "wrap", gap: 8 }}>
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <span style={{ fontSize: 10, color: C_AGENT.muted }}>Step {step.step}</span>
                          <AgentBadge label={step.phase.split("—")[0].trim()} color={phColor} />
                          <AgentBadge label={`Risk: ${step.risk}`} color={RISK_COLORS[step.risk] || C_AGENT.muted} />
                          <AgentBadge label={`Effort: ${step.effort}`} color={EFFORT_COLORS[step.effort] || C_AGENT.muted} />
                        </div>
                        <span style={{ fontSize: 11, color: C_AGENT.muted }}>⏱ {step.duration}</span>
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>{step.title}</div>
                      <div style={{ marginBottom: 10 }}>
                        {step.actions.map((a, i) => (
                          <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", padding: "4px 0", fontSize: 11, color: C_AGENT.muted, lineHeight: 1.6 }}>
                            <span style={{ color: phColor, flexShrink: 0 }}>{i + 1}.</span> {a}
                          </div>
                        ))}
                      </div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, fontSize: 11 }}>
                        <div style={{ background: C_AGENT.green + "0d", borderRadius: 6, padding: "7px 10px", color: C_AGENT.green }}>✓ Validation: {step.validation}</div>
                        <div style={{ background: C_AGENT.yellow + "0d", borderRadius: 6, padding: "7px 10px", color: C_AGENT.yellow }}>↩ Rollback: {step.rollback}</div>
                      </div>
                    </div>
                  );
                })}
              </>
            )}

            {/* ── EXPORT ── */}
            {subTab === "export" && (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                <div style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 12, padding: "24px 26px" }}>
                  <AgentSectionTitle>📄 Export JSON Report</AgentSectionTitle>
                  <div style={{ fontSize: 11, color: C_AGENT.muted, marginBottom: 18, lineHeight: 1.7 }}>
                    Full machine-readable report containing inventory, relationships, anomalies, target state decisions, and migration plan steps.
                  </div>
                  <div style={{ background: C_AGENT.sur2, borderRadius: 8, padding: "12px 14px", marginBottom: 16, fontSize: 10, color: C_AGENT.muted, fontFamily: "'JetBrains Mono',monospace", lineHeight: 1.7 }}>
                    <div style={{ color: C_AGENT.accent }}>mqoptima_report.json</div>
                    <div>├─ inventory ({inventory.summary.total_qms} QMs, {inventory.summary.total_channels} channels)</div>
                    <div>├─ relationships ({relationships.producer_consumer.length} flows)</div>
                    <div>├─ anomalies ({anomalies.length} issues)</div>
                    <div>├─ target_state ({targetState.architecture_pattern})</div>
                    <div>├─ decisions ({(decisions || []).length} explained)</div>
                    <div>└─ migration_plan ({migrationPlan.length} steps)</div>
                  </div>
                  <button
                    onClick={exportJSON}
                    style={{ padding: "10px 22px", background: `${C_AGENT.green}22`, border: `1px solid ${C_AGENT.green}60`, borderRadius: 8, color: C_AGENT.green, fontFamily: "'JetBrains Mono',monospace", fontSize: 12, cursor: "pointer", fontWeight: 700 }}
                  >
                    ↓ Download JSON
                  </button>
                </div>

                <div style={{ background: C_AGENT.sur, border: `1px solid ${C_AGENT.border}`, borderRadius: 12, padding: "24px 26px" }}>
                  <AgentSectionTitle>🖨️ Print / Export PDF</AgentSectionTitle>
                  <div style={{ fontSize: 11, color: C_AGENT.muted, marginBottom: 18, lineHeight: 1.7 }}>
                    Open the browser print dialog to save as PDF. The full report will be formatted for print with all sections visible.
                  </div>
                  <div style={{ background: C_AGENT.sur2, borderRadius: 8, padding: "12px 14px", marginBottom: 16, fontSize: 11, color: C_AGENT.muted, lineHeight: 1.7 }}>
                    <div>• Executive summary with health scores</div>
                    <div>• Full anomaly list</div>
                    <div>• Target state decisions with rationale</div>
                    <div>• Phased migration steps</div>
                  </div>
                  <button
                    onClick={() => window.print()}
                    style={{ padding: "10px 22px", background: `${C_AGENT.violet}22`, border: `1px solid ${C_AGENT.violet}60`, borderRadius: 8, color: C_AGENT.violet, fontFamily: "'JetBrains Mono',monospace", fontSize: 12, cursor: "pointer", fontWeight: 700 }}
                  >
                    🖨 Print / Save PDF
                  </button>
                </div>
              </div>
            )}
          </>
        );
      })()}
    </div>
  );
}
