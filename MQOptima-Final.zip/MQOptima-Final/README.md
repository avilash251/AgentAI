# ⬡ MQOptima — IBM MQ Topology Intelligence Platform

Full-stack AI-powered IBM MQ topology optimizer and intelligent inventory agent.
React frontend · FastAPI backend · LangGraph 5-agent pipeline · Gemini 2.5 Flash Lite

---

## 📁 Project Structure

```
MQOptima-Final/
├── frontend/
│   └── App.jsx                  # React UI — 7 tabs including Agent Pipeline
├── backend/
│   ├── mq_optimizer_backend.py  # FastAPI server (analysis + agent endpoints)
│   ├── mq_agent_pipeline.py     # LangGraph 5-agent pipeline (Gemini 2.5 Flash Lite)
│   └── requirements.txt         # Python dependencies
├── sample_topology.csv          # 16-channel demo MQ topology
├── previews/
│   ├── overview.png             # UI screenshot — Overview tab
│   ├── topology_graph.png       # UI screenshot — D3 force graph
│   └── issues_and_recommendations.png
└── README.md
```

---

## 🚀 Quick Start

### 1 — Backend

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set your Gemini API key
export GEMINI_API_KEY="your-gemini-api-key"

# Start the server
uvicorn mq_optimizer_backend:app --reload --port 8000
```

API available at **http://localhost:8000**
Swagger docs at **http://localhost:8000/docs**

---

### 2 — Frontend

```bash
# Option A — Vite (recommended)
npm create vite@latest mqoptima-ui -- --template react
cd mqoptima-ui
npm install d3
cp /path/to/App.jsx src/App.jsx
npm run dev
# → http://localhost:5173

# Option B — Create React App
npx create-react-app mqoptima-ui
cd mqoptima-ui
npm install d3
cp /path/to/App.jsx src/App.js
npm start
# → http://localhost:3000
```

#### Set your Gemini API key (frontend)
In the browser console or a startup script:
```js
window.__GEMINI_API_KEY__ = "your-gemini-api-key";
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET`  | `/` | Health check |
| `POST` | `/api/analyze` | Upload CSV → topology analysis (client-side algorithms) |
| `POST` | `/api/agent-analyze` | Upload CSV → full LangGraph 5-agent pipeline |
| `GET`  | `/api/sample-csv` | Returns the sample CSV |

---

## 🤖 LangGraph Agent Pipeline

Five agents run in sequence on `POST /api/agent-analyze`:

| # | Agent | What it does |
|---|-------|-------------|
| 1 | 🔍 Discovery Agent | Parses CSV → structured inventory of all QMs, queues, channels |
| 2 | 🔗 Relationship Agent | Maps producer/consumer pairs, application flows, traffic hubs |
| 3 | ⚠️ Anomaly Detector | DFS cycle detection, unused channels, fan-in/out, redundant paths |
| 4 | 🎯 Target State Agent | **Gemini 2.5 Flash Lite** — reasons about optimal architecture, produces decisions JSON |
| 5 | 📋 Migration Planner | Phased migration steps with risk/effort/duration/rollback + full report |

---

## 🖥️ UI Tabs

| Tab | Description |
|-----|-------------|
| Overview | Health gauge, 8 metric cards, complexity breakdown, optimization potential |
| Topology Graph | Interactive D3 force-directed graph — drag, zoom, color-coded edges |
| Issues | Routing cycles with break points, unused channels, fan-in/out violations |
| Recommendations | Prioritized action cards with effort/impact ratings |
| Optimized View | Post-transformation graph with delta metrics |
| ✦ AI Insights | **Gemini 2.5 Flash Lite** expert architecture assessment |
| ⬡ Agent Pipeline | Full 5-agent pipeline with 6 sub-tabs (see below) |

### Agent Pipeline Sub-tabs

| Sub-tab | Description |
|---------|-------------|
| Inventory | QM table + full channel inventory with status badges |
| Relationships | Producer/consumer map, hub QMs, top-5 critical paths |
| Anomalies | Severity-grouped issues with break points and impact |
| Before → After | Side-by-side D3 force graphs of current vs target topology |
| Decisions Explained | Gemini's rationale for every target state decision with trade-offs |
| Migration Plan | Phased steps: Cleanup → Structural → Modernisation, with validation & rollback |
| Export | JSON report download + Print/PDF via browser |

---

## 📄 CSV Format

| Column | Type | Description |
|--------|------|-------------|
| `source_qm` | string | Source Queue Manager |
| `target_qm` | string | Target Queue Manager |
| `channel_name` | string | Unique channel identifier |
| `channel_type` | string | e.g. `SENDER`, `RECEIVER` |
| `source_queue` | string | Queue on source QM |
| `target_queue` | string | Queue on target QM |
| `status` | string | `RUNNING` or `STOPPED` |
| `msg_rate` | integer | Messages per day |
| `application` | string | Owning application |

> A channel is **unused** if `status = STOPPED` **or** `msg_rate = 0`

---

## 🧠 Algorithms (client-side + backend)

- **Cycle Detection** — DFS with WHITE/GRAY/BLACK coloring
- **Fan-In / Fan-Out** — degree threshold > 3 on active edges
- **Avg Hops** — BFS across all QM pairs on active edges
- **Complexity Score** — `cycles×15 + unused×5 + fan_issues×8 + hop_overhead×8`
- **Optimization** — Remove unused → break lowest-traffic cycle edge → prune orphans

---

## 🔑 Environment Variables

| Variable | Where | Description |
|----------|-------|-------------|
| `GEMINI_API_KEY` | Backend (env) | Google Gemini API key for Target State Agent |
| `window.__GEMINI_API_KEY__` | Frontend (browser) | Gemini API key for AI Insights + Agent Pipeline tabs |

Get your key at: https://aistudio.google.com/app/apikey

---

## 📦 Dependencies

### Backend (`requirements.txt`)
| Package | Version | Purpose |
|---------|---------|---------|
| `fastapi` | 0.115.0 | Web framework |
| `uvicorn[standard]` | 0.30.6 | ASGI server |
| `networkx` | 3.3 | Graph algorithms |
| `pandas` | 2.2.2 | CSV parsing |
| `python-multipart` | 0.0.9 | File upload |
| `pydantic` | 2.8.2 | Data validation |
| `langgraph` | 0.2.28 | Multi-agent pipeline orchestration |
| `google-generativeai` | ≥0.8.0 | Gemini 2.5 Flash Lite LLM |

### Frontend
| Package | Purpose |
|---------|---------|
| `react` + `react-dom` | UI framework |
| `d3` | Force-directed topology graph |

---

## 📝 License

MIT — free to use, modify, and distribute.
