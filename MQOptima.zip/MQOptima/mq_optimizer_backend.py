"""
MQOptima - IBM MQ Topology Optimizer Backend
FastAPI + NetworkX graph analysis engine
Run: uvicorn main:app --reload --port 8000
"""

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Optional, Any
import pandas as pd
import networkx as nx
import io
import json

app = FastAPI(title="MQOptima API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────
# MODELS
# ─────────────────────────────────────────────

class Channel(BaseModel):
    source_qm: str
    target_qm: str
    channel_name: str
    channel_type: str = "SENDER"
    source_queue: str = ""
    target_queue: str = ""
    status: str = "RUNNING"
    msg_rate: int = 0
    application: str = ""
    is_unused: bool = False
    in_cycle: bool = False

class QueueManager(BaseModel):
    id: str
    total_traffic: int
    in_degree: int
    out_degree: int
    complexity_class: str  # CLEAN | CYCLE | HUB_IN | HUB_OUT | ISOLATED

class Cycle(BaseModel):
    nodes: List[str]
    edges: List[str]
    min_traffic_edge: Optional[str]
    min_traffic: int

class FanIssue(BaseModel):
    type: str  # FAN_IN | FAN_OUT
    qm: str
    degree: int
    peers: List[str]

class Recommendation(BaseModel):
    id: str
    priority: str  # CRITICAL | HIGH | MEDIUM | LOW
    category: str
    title: str
    description: str
    impact: str
    effort: str
    channels_reduced: int

class Metrics(BaseModel):
    total_channels: int
    active_channels: int
    unused_channels: int
    total_qms: int
    cycle_count: int
    fan_issues: int
    avg_hops: float
    max_hops: int
    complexity_score: int
    health_score: int
    total_traffic: int

class AnalysisResult(BaseModel):
    nodes: List[QueueManager]
    edges: List[Channel]
    cycles: List[Cycle]
    unused: List[Channel]
    fan_issues: List[FanIssue]
    metrics: Metrics
    recommendations: List[Recommendation]
    optimized: Dict[str, Any]
    opt_metrics: Metrics

# ─────────────────────────────────────────────
# CORE ALGORITHMS
# ─────────────────────────────────────────────

def parse_csv(content: bytes) -> pd.DataFrame:
    """Parse MQ topology CSV into a DataFrame."""
    df = pd.read_csv(io.BytesIO(content))
    df.columns = [c.strip().lower() for c in df.columns]
    required = {"source_qm", "target_qm", "channel_name"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    # Fill defaults
    df["status"] = df.get("status", pd.Series(["RUNNING"] * len(df))).fillna("RUNNING")
    df["msg_rate"] = pd.to_numeric(df.get("msg_rate", 0), errors="coerce").fillna(0).astype(int)
    df["channel_type"] = df.get("channel_type", pd.Series(["SENDER"] * len(df))).fillna("SENDER")
    df["source_queue"] = df.get("source_queue", pd.Series([""] * len(df))).fillna("")
    df["target_queue"] = df.get("target_queue", pd.Series([""] * len(df))).fillna("")
    df["application"] = df.get("application", pd.Series([""] * len(df))).fillna("")
    df["is_unused"] = (df["status"].str.upper() == "STOPPED") | (df["msg_rate"] == 0)
    df["in_cycle"] = False
    return df.dropna(subset=["source_qm", "target_qm"])


def build_graph(df: pd.DataFrame) -> nx.DiGraph:
    """Build directed multigraph from channel data."""
    G = nx.DiGraph()
    for _, row in df.iterrows():
        for qm in [row["source_qm"], row["target_qm"]]:
            if qm not in G:
                G.add_node(qm, total_traffic=0, in_degree=0, out_degree=0)
        if not row["is_unused"]:
            G.nodes[row["source_qm"]]["total_traffic"] += row["msg_rate"]
            G.nodes[row["target_qm"]]["total_traffic"] += row["msg_rate"]
        # Always track degree from full channel list
        G.nodes[row["source_qm"]]["out_degree"] = G.nodes[row["source_qm"]].get("out_degree", 0) + 1
        G.nodes[row["target_qm"]]["in_degree"] = G.nodes[row["target_qm"]].get("in_degree", 0) + 1
        G.add_edge(
            row["source_qm"], row["target_qm"],
            channel_name=row["channel_name"],
            channel_type=row["channel_type"],
            status=row["status"],
            msg_rate=int(row["msg_rate"]),
            application=row["application"],
            source_queue=row["source_queue"],
            target_queue=row["target_queue"],
            is_unused=bool(row["is_unused"]),
            in_cycle=False,
        )
    return G


def detect_cycles(G: nx.DiGraph) -> List[List[str]]:
    """Detect all simple cycles using Johnson's algorithm (via networkx)."""
    active_G = nx.DiGraph([(u, v) for u, v, d in G.edges(data=True) if not d.get("is_unused")])
    raw_cycles = list(nx.simple_cycles(active_G))
    # Deduplicate by canonical form
    seen = set()
    unique = []
    for c in raw_cycles:
        key = ",".join(sorted(c))
        if key not in seen:
            seen.add(key)
            unique.append(c + [c[0]])  # Close the cycle
    return unique


def mark_cycle_edges(df: pd.DataFrame, cycles: List[List[str]]) -> pd.DataFrame:
    """Mark edges that participate in cycles."""
    cycle_pairs = set()
    for cycle in cycles:
        for i in range(len(cycle) - 1):
            cycle_pairs.add((cycle[i], cycle[i + 1]))
    df["in_cycle"] = df.apply(
        lambda r: (r["source_qm"], r["target_qm"]) in cycle_pairs, axis=1
    )
    return df


def analyze_fan_patterns(G: nx.DiGraph, threshold: int = 3) -> List[FanIssue]:
    """Detect fan-in and fan-out violations."""
    issues = []
    for node in G.nodes():
        in_deg = G.in_degree(node)
        out_deg = G.out_degree(node)
        if in_deg > threshold:
            peers = [u for u in G.predecessors(node)]
            issues.append(FanIssue(type="FAN_IN", qm=node, degree=in_deg, peers=peers))
        if out_deg > threshold:
            peers = [v for v in G.successors(node)]
            issues.append(FanIssue(type="FAN_OUT", qm=node, degree=out_deg, peers=peers))
    return issues


def compute_avg_hops(G: nx.DiGraph) -> tuple[float, int]:
    """Compute average and max shortest path hops across all pairs."""
    active_G = nx.DiGraph([(u, v) for u, v, d in G.edges(data=True) if not d.get("is_unused")])
    all_hops = []
    for source in active_G.nodes():
        lengths = nx.single_source_shortest_path_length(active_G, source)
        for target, dist in lengths.items():
            if target != source and dist > 0:
                all_hops.append(dist)
    if not all_hops:
        return 0.0, 0
    return round(sum(all_hops) / len(all_hops), 2), max(all_hops)


def calculate_metrics(G: nx.DiGraph, df: pd.DataFrame, cycles: List, fan_issues: List) -> Metrics:
    """Compute quantitative complexity metrics."""
    unused = df[df["is_unused"]]
    active = df[~df["is_unused"]]
    avg_hops, max_hops = compute_avg_hops(G)

    complexity_score = min(100, int(
        len(cycles) * 15 +
        len(unused) * 5 +
        len(fan_issues) * 8 +
        max(0, (avg_hops - 2) * 8)
    ))
    health_score = max(0, 100 - complexity_score)

    return Metrics(
        total_channels=len(df),
        active_channels=len(active),
        unused_channels=len(unused),
        total_qms=len(G.nodes()),
        cycle_count=len(cycles),
        fan_issues=len(fan_issues),
        avg_hops=avg_hops,
        max_hops=max_hops,
        complexity_score=complexity_score,
        health_score=health_score,
        total_traffic=int(df["msg_rate"].sum()),
    )


def enrich_cycles(df: pd.DataFrame, cycles: List[List[str]]) -> List[Cycle]:
    """Build enriched Cycle objects with edge names and min-traffic edge."""
    result = []
    for cycle in cycles:
        edge_names = []
        min_traffic = float("inf")
        min_edge = None
        for i in range(len(cycle) - 1):
            match = df[(df["source_qm"] == cycle[i]) & (df["target_qm"] == cycle[i + 1])]
            if not match.empty:
                row = match.iloc[0]
                edge_names.append(row["channel_name"])
                if row["msg_rate"] < min_traffic:
                    min_traffic = row["msg_rate"]
                    min_edge = row["channel_name"]
        result.append(Cycle(
            nodes=cycle[:-1],
            edges=edge_names,
            min_traffic_edge=min_edge,
            min_traffic=int(min_traffic) if min_traffic != float("inf") else 0,
        ))
    return result


def generate_recommendations(
    df: pd.DataFrame, cycles: List[Cycle], fan_issues: List[FanIssue]
) -> List[Recommendation]:
    """Generate prioritized, actionable recommendations."""
    recs = []
    counter = [1]

    def next_id():
        id_ = f"R{counter[0]:02d}"
        counter[0] += 1
        return id_

    unused = df[df["is_unused"]]
    if not unused.empty:
        names = ", ".join(unused["channel_name"].tolist()[:5])
        if len(unused) > 5:
            names += f" (+{len(unused) - 5} more)"
        recs.append(Recommendation(
            id=next_id(), priority="HIGH", category="Cleanup",
            title=f"Decommission {len(unused)} unused channel(s)",
            description=f"Remove STOPPED/zero-traffic channels: {names}. "
                        "Verify with application teams before deletion.",
            impact=f"Reduces object count by {len(unused)}, eliminates dead configuration",
            effort="LOW", channels_reduced=len(unused),
        ))

    for cycle in cycles:
        recs.append(Recommendation(
            id=next_id(), priority="CRITICAL", category="Cycle Breaking",
            title=f"Break routing cycle: {' → '.join(cycle.nodes)}",
            description=f"Closed loop detected. Recommended: redirect or remove "
                        f"'{cycle.min_traffic_edge}' ({cycle.min_traffic} msg/day). "
                        "Replace with async event or one-way notification pattern.",
            impact="Eliminates infinite routing risk, reduces message amplification",
            effort="MEDIUM", channels_reduced=1,
        ))

    for fi in fan_issues:
        if fi.type == "FAN_IN":
            recs.append(Recommendation(
                id=next_id(), priority="MEDIUM", category="Fan-In Reduction",
                title=f"Introduce aggregator QM upstream of {fi.qm}",
                description=f"{fi.qm} receives from {fi.degree} sources ({', '.join(fi.peers[:4])}). "
                            "A dedicated aggregator QM consolidates upstream traffic.",
                impact=f"Reduces direct incoming connections by {fi.degree - 1}",
                effort="HIGH", channels_reduced=fi.degree - 1,
            ))
        else:
            recs.append(Recommendation(
                id=next_id(), priority="MEDIUM", category="Fan-Out Reduction",
                title=f"Apply publish-subscribe pattern at {fi.qm}",
                description=f"{fi.qm} dispatches to {fi.degree} targets. "
                            "A topic-based routing layer decouples producers from consumers.",
                impact=f"Standardizes distribution, reduces point-to-point coupling",
                effort="HIGH", channels_reduced=fi.degree // 2,
            ))

    return recs


def build_optimized_topology(df: pd.DataFrame, cycles: List[Cycle]) -> pd.DataFrame:
    """Apply transformations: remove unused, break cycles."""
    opt = df[~df["is_unused"]].copy()
    # Break each cycle by removing lowest-traffic edge
    for cycle in cycles:
        if cycle.min_traffic_edge:
            opt = opt[opt["channel_name"] != cycle.min_traffic_edge]
    return opt


def df_to_nodes(df: pd.DataFrame) -> List[QueueManager]:
    """Convert dataframe to QueueManager list."""
    nodes = {}
    for _, row in df.iterrows():
        for qm in [row["source_qm"], row["target_qm"]]:
            if qm not in nodes:
                nodes[qm] = {"id": qm, "total_traffic": 0, "in_degree": 0, "out_degree": 0}
        nodes[row["source_qm"]]["total_traffic"] += row["msg_rate"]
        nodes[row["source_qm"]]["out_degree"] += 1
        nodes[row["target_qm"]]["total_traffic"] += row["msg_rate"]
        nodes[row["target_qm"]]["in_degree"] += 1

    result = []
    for n in nodes.values():
        in_cycle_flag = any(
            (row["source_qm"] == n["id"] or row["target_qm"] == n["id"]) and row["in_cycle"]
            for _, row in df.iterrows()
        )
        if n["in_degree"] == 0 and n["out_degree"] == 0:
            cls = "ISOLATED"
        elif in_cycle_flag:
            cls = "CYCLE"
        elif n["in_degree"] > 3:
            cls = "HUB_IN"
        elif n["out_degree"] > 3:
            cls = "HUB_OUT"
        else:
            cls = "CLEAN"
        result.append(QueueManager(complexity_class=cls, **{k: v for k, v in n.items() if k != "complexity_class"}))
    return result


# ─────────────────────────────────────────────
# API ENDPOINTS
# ─────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "ok", "service": "MQOptima API v1.0"}


@app.post("/api/analyze", response_model=AnalysisResult)
async def analyze_topology(file: UploadFile = File(...)):
    """Upload a CSV and get full topology analysis."""
    if not file.filename.endswith(".csv"):
        raise HTTPException(400, "Only CSV files are accepted")

    content = await file.read()
    try:
        df = parse_csv(content)
    except Exception as e:
        raise HTTPException(400, f"CSV parse error: {e}")

    G = build_graph(df)
    cycles_raw = detect_cycles(G)
    df = mark_cycle_edges(df, cycles_raw)
    cycles = enrich_cycles(df, cycles_raw)
    unused = df[df["is_unused"]]
    fan_issues = analyze_fan_patterns(G)
    metrics = calculate_metrics(G, df, cycles, fan_issues)
    recommendations = generate_recommendations(df, cycles, fan_issues)

    # Optimized topology
    opt_df = build_optimized_topology(df, cycles)
    opt_G = build_graph(opt_df)
    opt_fan = analyze_fan_patterns(opt_G)
    opt_metrics = calculate_metrics(opt_G, opt_df, [], opt_fan)

    nodes_list = df_to_nodes(df)
    edges_list = [
        Channel(
            source_qm=row["source_qm"], target_qm=row["target_qm"],
            channel_name=row["channel_name"], channel_type=row["channel_type"],
            source_queue=row["source_queue"], target_queue=row["target_queue"],
            status=row["status"], msg_rate=int(row["msg_rate"]),
            application=row["application"],
            is_unused=bool(row["is_unused"]), in_cycle=bool(row["in_cycle"]),
        )
        for _, row in df.iterrows()
    ]
    opt_edges = [
        Channel(
            source_qm=row["source_qm"], target_qm=row["target_qm"],
            channel_name=row["channel_name"], channel_type=row["channel_type"],
            source_queue=row["source_queue"], target_queue=row["target_queue"],
            status=row["status"], msg_rate=int(row["msg_rate"]),
            application=row["application"],
            is_unused=False, in_cycle=False,
        )
        for _, row in opt_df.iterrows()
    ]
    opt_nodes = df_to_nodes(opt_df)

    return AnalysisResult(
        nodes=nodes_list,
        edges=edges_list,
        cycles=cycles,
        unused=[Channel(**{k: row[k] for k in Channel.__fields__ if k in row}, is_unused=True, in_cycle=False) for _, row in unused.iterrows()],
        fan_issues=fan_issues,
        metrics=metrics,
        recommendations=recommendations,
        optimized={"nodes": [n.dict() for n in opt_nodes], "edges": [e.dict() for e in opt_edges]},
        opt_metrics=opt_metrics,
    )


@app.get("/api/sample-csv")
def sample_csv():
    """Return sample CSV content for testing."""
    return {
        "filename": "sample_mq_topology.csv",
        "content": SAMPLE_CSV,
    }


SAMPLE_CSV = """source_qm,target_qm,channel_name,channel_type,source_queue,target_queue,status,msg_rate,application
QM_CORE,QM_ORDER,CHAN.CORE.ORDER,SENDER,CORE.OUT,ORDER.IN,RUNNING,2400,OrderService
QM_ORDER,QM_PAYMENT,CHAN.ORDER.PAYMENT,SENDER,ORDER.OUT,PAYMENT.IN,RUNNING,1800,PaymentService
QM_PAYMENT,QM_CORE,CHAN.PAYMENT.CORE,SENDER,PAYMENT.OUT,CORE.IN,RUNNING,300,AuditLoop
QM_ORDER,QM_INVENTORY,CHAN.ORDER.INV,SENDER,ORDER.STOCK,INV.IN,RUNNING,900,InventoryService
QM_INVENTORY,QM_NOTIFY,CHAN.INV.NOTIFY,SENDER,INV.ALERT,NOTIFY.IN,RUNNING,300,NotifyService
QM_NOTIFY,QM_AUDIT,CHAN.NOTIFY.AUDIT,SENDER,NOTIFY.OUT,AUDIT.IN,RUNNING,150,AuditService
QM_AUDIT,QM_ARCHIVE,CHAN.AUDIT.ARCHIVE,SENDER,AUDIT.OUT,ARCH.IN,RUNNING,120,ArchiveService
QM_CORE,QM_LEGACY,CHAN.CORE.LEGACY,SENDER,CORE.LEGACY,LEGACY.IN,STOPPED,0,LegacyMigrated
QM_LEGACY,QM_ARCHIVE,CHAN.LEGACY.ARCH,SENDER,LEGACY.OUT,ARCH.IN,STOPPED,0,ArchivedFlow
QM_CORE,QM_PAYMENT,CHAN.CORE.PAY.OLD,SENDER,CORE.PAY,PAYMENT.DIRECT,STOPPED,0,OldDirect
QM_PAYMENT,QM_NOTIFY,CHAN.PAY.NOTIFY,SENDER,PAY.NOTIFY,NOTIFY.PAY,RUNNING,600,PayAlerts
QM_ORDER,QM_AUDIT,CHAN.ORDER.AUDIT,SENDER,ORDER.AUDIT,AUDIT.IN,RUNNING,400,AuditTrail
QM_PAYMENT,QM_AUDIT,CHAN.PAY.AUDIT,SENDER,PAY.AUDIT,AUDIT.IN,RUNNING,350,AuditTrail
QM_INVENTORY,QM_AUDIT,CHAN.INV.AUDIT,SENDER,INV.AUDIT,AUDIT.IN,RUNNING,120,AuditTrail
QM_ORDER,QM_CORE,CHAN.ORDER.CORE,SENDER,ORDER.RESP,CORE.RESP,RUNNING,500,OrderResponse
QM_INVENTORY,QM_CORE,CHAN.INV.CORE,SENDER,INV.RESP,CORE.RESP,RUNNING,200,InvResponse"""


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
