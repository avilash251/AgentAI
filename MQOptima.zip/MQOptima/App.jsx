// MQOptima — IBM MQ Topology Optimizer
// React + D3 + Anthropic API

import { useState, useEffect, useRef, useCallback } from "react";
import * as d3 from "d3";

// ═══════════════════════════════════════════════════════
// SAMPLE DATA
// ═══════════════════════════════════════════════════════
const SAMPLE_CSV = `source_qm,target_qm,channel_name,channel_type,source_queue,target_queue,status,msg_rate,application
QM_CORE,QM_ORDER,CHAN.CORE.ORDER,SENDER,CORE.OUT,ORDER.IN,RUNNING,2400,OrderService
QM_ORDER,QM_PAYMENT,CHAN.ORDER.PAYMENT,SENDER,ORDER.OUT,PAYMENT.IN,RUNNING,1800,PaymentService
QM_PAYMENT,QM_CORE,CHAN.PAYMENT.CORE,SENDER,PAYMENT.OUT,CORE.IN,RUNNING,300,AuditLoop
QM_ORDER,QM_INVENTORY,CHAN.ORDER.INV,SENDER,ORDER.STOCK,INV.IN,RUNNING,900,InventoryService
QM_INVENTORY,QM_NOTIFY,CHAN.INV.NOTIFY,SENDER,INV.ALERT,NOTIFY.IN,RUNNING,300,NotifyService
QM_NOTIFY,QM_AUDIT,CHAN.NOTIFY.AUDIT,SENDER,NOTIFY.OUT,AUDIT.IN,RUNNING,150,AuditService
QM_AUDIT,QM_ARCHIVE,CHAN.AUDIT.ARCHIVE,SENDER,AUDIT.OUT,ARCH.IN,RUNNING,120,ArchiveService
QM_CORE,QM_LEGACY,CHAN.CORE.LEGACY,SENDER,CORE.LEGACY,LEGACY.IN,STOPPED,0,LegacyMigrated
QM_LEGACY,QM_ARCHIVE,CHAN.LEGACY.ARCH,SENDER,LEGACY.OUT,ARCH.IN,STOPPED,0,ArchivedFlow
QM_CORE,QM_PAYMENT,CHAN.CORE.PAY.OLD,SENDER,CORE.PAY,PAYMENT.DIRECT,STOPPED,0,OldDirect
QM_PAYMENT,QM_NOTIFY,CHAN.PAY.NOTIFY,SENDER,PAY.NOTIFY,NOTIFY.PAY,RUNNING,600,PayAlerts
QM_ORDER,QM_AUDIT,CHAN.ORDER.AUDIT,SENDER,ORDER.AUDIT,AUDIT.IN,RUNNING,400,AuditTrail
QM_PAYMENT,QM_AUDIT,CHAN.PAY.AUDIT,SENDER,PAY.AUDIT,AUDIT.IN,RUNNING,350,AuditTrail
QM_INVENTORY,QM_AUDIT,CHAN.INV.AUDIT,SENDER,INV.AUDIT,AUDIT.IN,RUNNING,120,AuditTrail
QM_ORDER,QM_CORE,CHAN.ORDER.CORE,SENDER,ORDER.RESP,CORE.RESP,RUNNING,500,OrderResponse
QM_INVENTORY,QM_CORE,CHAN.INV.CORE,SENDER,INV.RESP,CORE.RESP,RUNNING,200,InvResponse`;

// ═══════════════════════════════════════════════════════
// ALGORITHMS
// ═══════════════════════════════════════════════════════

function parseCSV(text) {
  const lines = text.trim().split("\n").filter(l => l.trim());
  if (lines.length < 2) return [];
  const headers = lines[0].split(",").map(h => h.trim().toLowerCase());
  return lines.slice(1).map(line => {
    const vals = line.split(",").map(v => v.trim());
    const row = {};
    headers.forEach((h, i) => row[h] = vals[i] || "");
    row.msg_rate = parseInt(row.msg_rate) || 0;
    row.is_unused = (row.status || "").toUpperCase() === "STOPPED" || row.msg_rate === 0;
    row.in_cycle = false;
    return row;
  }).filter(r => r.source_qm && r.target_qm);
}

function buildGraph(rows) {
  const nodeMap = new Map();
  const edges = rows.map((row, i) => {
    for (const qm of [row.source_qm, row.target_qm]) {
      if (!nodeMap.has(qm)) nodeMap.set(qm, { id: qm, totalTraffic: 0, inDegree: 0, outDegree: 0 });
    }
    nodeMap.get(row.source_qm).outDegree++;
    nodeMap.get(row.target_qm).inDegree++;
    nodeMap.get(row.source_qm).totalTraffic += row.msg_rate;
    nodeMap.get(row.target_qm).totalTraffic += row.msg_rate;
    return { ...row, edgeId: `e${i}` };
  });
  return { nodes: Array.from(nodeMap.values()), edges };
}

function detectCycles(nodes, edges) {
  const adj = new Map();
  nodes.forEach(n => adj.set(n.id, []));
  edges.forEach(e => { if (!e.is_unused) adj.get(e.source_qm)?.push(e.target_qm); });

  const cycles = [];
  const WHITE = 0, GRAY = 1, BLACK = 2;
  const color = new Map(nodes.map(n => [n.id, WHITE]));
  const path = [];

  function dfs(u) {
    color.set(u, GRAY);
    path.push(u);
    for (const v of (adj.get(u) || [])) {
      if (color.get(v) === GRAY) {
        const start = path.indexOf(v);
        const cycle = [...path.slice(start), v];
        const key = [...cycle.slice(0, -1)].sort().join(",");
        cycles.push({ nodes: cycle, key });
      } else if (color.get(v) === WHITE) {
        dfs(v);
      }
    }
    path.pop();
    color.set(u, BLACK);
  }

  nodes.forEach(n => { if (color.get(n.id) === WHITE) dfs(n.id); });

  // Deduplicate
  const seen = new Set();
  return cycles.filter(c => {
    if (seen.has(c.key)) return false;
    seen.add(c.key);
    return true;
  }).map(c => c.nodes);
}

function markCycleEdges(edges, cycles) {
  const cycleSet = new Set();
  cycles.forEach(c => {
    for (let i = 0; i < c.length - 1; i++) cycleSet.add(`${c[i]}->${c[i + 1]}`);
  });
  edges.forEach(e => { e.in_cycle = cycleSet.has(`${e.source_qm}->${e.target_qm}`); });
}

function analyzeFanPatterns(nodes, edges, threshold = 3) {
  const issues = [];
  nodes.forEach(n => {
    const activeIn = edges.filter(e => e.target_qm === n.id && !e.is_unused);
    const activeOut = edges.filter(e => e.source_qm === n.id && !e.is_unused);
    if (activeIn.length > threshold)
      issues.push({ type: "FAN_IN", qm: n.id, degree: activeIn.length, peers: activeIn.map(e => e.source_qm) });
    if (activeOut.length > threshold)
      issues.push({ type: "FAN_OUT", qm: n.id, degree: activeOut.length, peers: activeOut.map(e => e.target_qm) });
  });
  return issues;
}

function computeAvgHops(nodes, edges) {
  const adj = new Map();
  nodes.forEach(n => adj.set(n.id, []));
  edges.filter(e => !e.is_unused).forEach(e => adj.get(e.source_qm)?.push(e.target_qm));
  let total = 0, count = 0;
  nodes.forEach(src => {
    const dist = new Map([[src.id, 0]]);
    const q = [src.id];
    while (q.length) {
      const u = q.shift();
      for (const v of (adj.get(u) || [])) {
        if (!dist.has(v)) { dist.set(v, dist.get(u) + 1); q.push(v); total += dist.get(v); count++; }
      }
    }
  });
  return count > 0 ? parseFloat((total / count).toFixed(2)) : 0;
}

function calculateMetrics(nodes, edges, cycles, fanIssues) {
  const unused = edges.filter(e => e.is_unused);
  const avgHops = computeAvgHops(nodes, edges);
  const complexityScore = Math.min(100, Math.round(
    cycles.length * 15 + unused.length * 5 + fanIssues.length * 8 + Math.max(0, (avgHops - 2) * 8)
  ));
  return {
    totalChannels: edges.length,
    activeChannels: edges.filter(e => !e.is_unused).length,
    unusedChannels: unused.length,
    totalQMs: nodes.length,
    cycles: cycles.length,
    fanIssues: fanIssues.length,
    avgHops,
    complexityScore,
    healthScore: Math.max(0, 100 - complexityScore),
    totalTraffic: edges.reduce((s, e) => s + e.msg_rate, 0),
  };
}

function generateRecommendations(edges, cycles, fanIssues) {
  const recs = [];
  let rid = 1;
  const unused = edges.filter(e => e.is_unused);
  if (unused.length > 0) {
    recs.push({
      id: `R${String(rid++).padStart(2, "0")}`, priority: "HIGH", category: "Cleanup",
      title: `Decommission ${unused.length} unused channel(s)`,
      description: `Remove: ${unused.slice(0, 4).map(e => e.channel_name).join(", ")}${unused.length > 4 ? " …" : ""}. Confirm with application teams first.`,
      impact: `Removes ${unused.length} dead objects, reduces security attack surface`,
      effort: "LOW", channelsReduced: unused.length,
    });
  }
  cycles.forEach(cycle => {
    const cycleEdges = [];
    for (let i = 0; i < cycle.length - 1; i++) {
      const e = edges.find(e => e.source_qm === cycle[i] && e.target_qm === cycle[i + 1] && !e.is_unused);
      if (e) cycleEdges.push(e);
    }
    const minEdge = cycleEdges.length > 0 ? cycleEdges.reduce((m, e) => e.msg_rate < m.msg_rate ? e : m, cycleEdges[0]) : null;
    recs.push({
      id: `R${String(rid++).padStart(2, "0")}`, priority: "CRITICAL", category: "Cycle Breaking",
      title: `Break cycle: ${cycle.slice(0, -1).join(" → ")}`,
      description: `Circular routing detected. Lowest-traffic edge to remove/redirect: ${minEdge?.channel_name || "unknown"} (${minEdge?.msg_rate || 0} msg/day). Replace with event-driven async pattern.`,
      impact: "Eliminates infinite routing loop risk, reduces message amplification",
      effort: "MEDIUM", channelsReduced: 1,
    });
  });
  fanIssues.forEach(fi => {
    if (fi.type === "FAN_IN") {
      recs.push({
        id: `R${String(rid++).padStart(2, "0")}`, priority: "MEDIUM", category: "Fan-In Reduction",
        title: `Add aggregator upstream of ${fi.qm}`,
        description: `${fi.qm} receives from ${fi.degree} sources. Introduce a dedicated aggregator QM to consolidate upstream traffic into a single channel.`,
        impact: `Reduces incoming connections to ${fi.qm} by ${fi.degree - 1}`,
        effort: "HIGH", channelsReduced: fi.degree - 1,
      });
    } else {
      recs.push({
        id: `R${String(rid++).padStart(2, "0")}`, priority: "MEDIUM", category: "Fan-Out Reduction",
        title: `Apply pub/sub pattern at ${fi.qm}`,
        description: `${fi.qm} dispatches to ${fi.degree} targets. Introduce topic-based routing to decouple producer from consumers.`,
        impact: "Decouples consumers, simplifies onboarding of new services",
        effort: "HIGH", channelsReduced: Math.floor(fi.degree / 2),
      });
    }
  });
  return recs;
}

function buildOptimized(nodes, edges, cycles) {
  let opt = edges.filter(e => !e.is_unused).map(e => ({ ...e }));
  cycles.forEach(cycle => {
    const cycleEdges = [];
    for (let i = 0; i < cycle.length - 1; i++) {
      const e = opt.find(e => e.source_qm === cycle[i] && e.target_qm === cycle[i + 1]);
      if (e) cycleEdges.push(e);
    }
    if (cycleEdges.length > 0) {
      const minEdge = cycleEdges.reduce((m, e) => e.msg_rate < m.msg_rate ? e : m, cycleEdges[0]);
      opt = opt.filter(e => e.edgeId !== minEdge.edgeId);
    }
  });
  const nodeIds = new Set([...opt.map(e => e.source_qm), ...opt.map(e => e.target_qm)]);
  const optNodes = nodes
    .filter(n => nodeIds.has(n.id))
    .map(n => ({
      ...n,
      inDegree: opt.filter(e => e.target_qm === n.id).length,
      outDegree: opt.filter(e => e.source_qm === n.id).length,
      totalTraffic: opt.filter(e => e.source_qm === n.id || e.target_qm === n.id).reduce((s, e) => s + e.msg_rate, 0),
    }));
  return { nodes: optNodes, edges: opt };
}

// ═══════════════════════════════════════════════════════
// D3 FORCE GRAPH
// ═══════════════════════════════════════════════════════

function ForceGraph({ nodes, edges, height = 480, title = "" }) {
  const containerRef = useRef(null);
  const svgRef = useRef(null);

  useEffect(() => {
    if (!svgRef.current || !nodes.length) return;
    const W = containerRef.current?.offsetWidth || 800;
    const H = height;
    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();
    svg.attr("viewBox", `0 0 ${W} ${H}`).attr("width", W).attr("height", H);

    // Defs
    const defs = svg.append("defs");
    const glow = defs.append("filter").attr("id", "glow-f");
    glow.append("feGaussianBlur").attr("stdDeviation", "3.5").attr("result", "blur");
    const mg = glow.append("feMerge");
    mg.append("feMergeNode").attr("in", "blur");
    mg.append("feMergeNode").attr("in", "SourceGraphic");

    const addMarker = (id, color) => {
      defs.append("marker").attr("id", id)
        .attr("viewBox", "0 -5 10 10").attr("refX", 30).attr("refY", 0)
        .attr("markerWidth", 5).attr("markerHeight", 5).attr("orient", "auto")
        .append("path").attr("d", "M0,-5L10,0L0,5").attr("fill", color);
    };
    addMarker("arr-active", "#10b981");
    addMarker("arr-cycle", "#f59e0b");
    addMarker("arr-unused", "#ef444455");

    svg.append("rect").attr("width", W).attr("height", H).attr("fill", "#07101f").attr("rx", 10);

    const nodeData = nodes.map(n => ({ ...n }));
    const linkData = edges.map(e => ({ ...e }));

    const sim = d3.forceSimulation(nodeData)
      .force("link", d3.forceLink(linkData).id(d => d.id).distance(130).strength(0.4))
      .force("charge", d3.forceManyBody().strength(-500))
      .force("center", d3.forceCenter(W / 2, H / 2))
      .force("collide", d3.forceCollide(46));

    const g = svg.append("g");
    svg.call(d3.zoom().scaleExtent([0.2, 3]).on("zoom", ev => g.attr("transform", ev.transform)));

    // Links
    const link = g.append("g").selectAll("line").data(linkData).enter().append("line")
      .attr("stroke", d => d.is_unused ? "#ef444440" : d.in_cycle ? "#f59e0b" : "#10b981")
      .attr("stroke-width", d => d.is_unused ? 1 : Math.max(1.5, Math.min(4, d.msg_rate / 700)))
      .attr("stroke-dasharray", d => d.is_unused ? "5,4" : "none")
      .attr("opacity", d => d.is_unused ? 0.4 : 0.75)
      .attr("marker-end", d => `url(#${d.is_unused ? "arr-unused" : d.in_cycle ? "arr-cycle" : "arr-active"})`);
    link.append("title").text(d => `${d.channel_name}\n${d.source_qm} → ${d.target_qm}\nStatus: ${d.status} | Traffic: ${d.msg_rate} msg/day\nApp: ${d.application || "N/A"}`);

    // Node groups
    const getColor = d => {
      if (edges.some(e => (e.source_qm === d.id || e.target_qm === d.id) && e.in_cycle)) return "#ef4444";
      if (d.inDegree > 3) return "#f59e0b";
      if (d.outDegree > 3) return "#a855f7";
      if (d.inDegree === 0 && d.outDegree === 0) return "#475569";
      return "#3b82f6";
    };

    const node = g.append("g").selectAll("g").data(nodeData).enter().append("g")
      .attr("cursor", "grab")
      .call(d3.drag()
        .on("start", (ev, d) => { if (!ev.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
        .on("drag", (ev, d) => { d.fx = ev.x; d.fy = ev.y; })
        .on("end", (ev, d) => { if (!ev.active) sim.alphaTarget(0); d.fx = null; d.fy = null; })
      );

    node.append("circle").attr("r", d => Math.max(22, Math.min(34, 16 + d.totalTraffic / 350)))
      .attr("fill", d => getColor(d) + "25")
      .attr("stroke", getColor).attr("stroke-width", 2.5)
      .attr("filter", "url(#glow-f)");

    node.append("text").attr("text-anchor", "middle").attr("dy", "0.38em")
      .attr("font-size", 9.5).attr("font-family", "monospace").attr("fill", "#dde5f0").attr("font-weight", "700")
      .text(d => d.id.replace("QM_", ""));

    node.append("title").text(d => `${d.id}\nIn: ${d.inDegree} | Out: ${d.outDegree}\nTraffic: ${d.totalTraffic} msg/day`);

    sim.on("tick", () => {
      link.attr("x1", d => d.source.x).attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x).attr("y2", d => d.target.y);
      node.attr("transform", d => `translate(${d.x},${d.y})`);
    });

    return () => sim.stop();
  }, [nodes, edges, height]);

  return (
    <div ref={containerRef} style={{ width: "100%", borderRadius: 10, overflow: "hidden", border: "1px solid #1a2e50" }}>
      <svg ref={svgRef} style={{ display: "block", width: "100%" }} />
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// STYLES
// ═══════════════════════════════════════════════════════
const C = {
  bg: "#050c18", sur: "#0b1628", sur2: "#0f1e36",
  border: "#1a2e50", accent: "#00d9ff", violet: "#8b5cf6",
  green: "#10b981", yellow: "#f59e0b", red: "#ef4444", blue: "#3b82f6",
  text: "#dde5f0", muted: "#64748b", orange: "#f97316",
};
const font = "'JetBrains Mono', 'Cascadia Code', 'Courier New', monospace";

const S = {
  app: { minHeight: "100vh", background: C.bg, color: C.text, fontFamily: font, fontSize: 13 },
  hdr: { background: `linear-gradient(135deg, ${C.sur} 0%, ${C.sur2} 100%)`, borderBottom: `1px solid ${C.border}`, padding: "14px 28px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 100 },
  logoBox: { width: 44, height: 44, background: `linear-gradient(135deg, ${C.accent}, ${C.violet})`, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 },
  main: { maxWidth: 1440, margin: "0 auto", padding: "24px 20px" },
  card: (accent = C.border) => ({ background: C.sur, border: `1px solid ${C.border}`, borderLeft: `3px solid ${accent}`, borderRadius: 12, padding: "20px 22px" }),
  grid: (cols) => ({ display: "grid", gridTemplateColumns: `repeat(auto-fit, minmax(${cols}px, 1fr))`, gap: 16 }),
  tabs: { display: "flex", gap: 4, padding: "4px", background: C.sur, border: `1px solid ${C.border}`, borderRadius: 12, marginBottom: 24, overflowX: "auto" },
  tab: (a) => ({ padding: "8px 18px", borderRadius: 9, cursor: "pointer", fontFamily: font, fontSize: 12, fontWeight: a ? 600 : 400, color: a ? C.accent : C.muted, background: a ? C.sur2 : "transparent", border: a ? `1px solid ${C.border}` : "1px solid transparent", whiteSpace: "nowrap", transition: "all 0.15s" }),
  metVal: (c) => ({ fontSize: 34, fontWeight: 700, color: c, lineHeight: 1, letterSpacing: "-0.02em" }),
  metLbl: { fontSize: 10, color: C.muted, marginTop: 8, textTransform: "uppercase", letterSpacing: "0.06em" },
  sec: { background: C.sur, border: `1px solid ${C.border}`, borderRadius: 12, padding: "20px 22px", marginBottom: 18 },
  secTitle: { fontSize: 11, fontWeight: 700, color: C.accent, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 },
  badge: (c) => ({ display: "inline-block", padding: "2px 8px", borderRadius: 4, background: c + "22", color: c, fontSize: 10, fontWeight: 700, letterSpacing: "0.05em", whiteSpace: "nowrap" }),
  issueRow: (c) => ({ display: "flex", gap: 12, padding: "12px 14px", background: C.sur2, borderRadius: 8, marginBottom: 8, borderLeft: `3px solid ${c}` }),
  recCard: (c) => ({ background: C.sur2, borderRadius: 10, padding: "16px", marginBottom: 14, border: `1px solid ${c}30` }),
  bar: (pct, c) => ({ height: 6, background: c, borderRadius: 3, width: `${Math.min(100, pct)}%`, transition: "width 0.6s ease" }),
  upload: (drag) => ({ border: `2px dashed ${drag ? C.accent : C.border}`, borderRadius: 14, padding: "28px 20px", textAlign: "center", cursor: "pointer", background: drag ? C.accent + "0a" : C.sur, transition: "all 0.2s", marginBottom: 22 }),
  aiBox: { background: "linear-gradient(135deg, #0f1e36 0%, #0a1428 100%)", border: `1px solid ${C.violet}40`, borderRadius: 12, padding: "20px", marginBottom: 18 },
};

const priorityColor = { CRITICAL: C.red, HIGH: C.yellow, MEDIUM: C.blue, LOW: C.green };
const effortColor = { LOW: C.green, MEDIUM: C.yellow, HIGH: C.orange };

// ═══════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════
export default function App() {
  const [tab, setTab] = useState("overview");
  const [topo, setTopo] = useState(null);
  const [drag, setDrag] = useState(false);
  const [loading, setLoading] = useState(false);
  const [aiText, setAiText] = useState("");
  const [aiLoading, setAiLoading] = useState(false);

  const analyze = useCallback((csvText) => {
    setLoading(true);
    setTimeout(() => {
      const rows = parseCSV(csvText);
      const { nodes, edges } = buildGraph(rows);
      const cycles = detectCycles(nodes, edges);
      markCycleEdges(edges, cycles);
      const unused = edges.filter(e => e.is_unused);
      const fanIssues = analyzeFanPatterns(nodes, edges);
      const metrics = calculateMetrics(nodes, edges, cycles, fanIssues);
      const recommendations = generateRecommendations(edges, cycles, fanIssues);
      const opt = buildOptimized(nodes, edges, cycles);
      const optFan = analyzeFanPatterns(opt.nodes, opt.edges);
      const optMetrics = calculateMetrics(opt.nodes, opt.edges, [], optFan);
      setTopo({ nodes, edges, cycles, unused, fanIssues, metrics, recommendations, opt, optMetrics });
      setTab("overview");
      setLoading(false);
    }, 500);
  }, []);

  useEffect(() => { analyze(SAMPLE_CSV); }, []);

  const handleFile = f => { const r = new FileReader(); r.onload = e => analyze(e.target.result); r.readAsText(f); };

  const fetchAI = async () => {
    if (!topo) return;
    setAiLoading(true);
    setAiText("");
    const summary = {
      queueManagers: topo.metrics.totalQMs,
      totalChannels: topo.metrics.totalChannels,
      unusedChannels: topo.metrics.unusedChannels,
      cycles: topo.metrics.cycles,
      fanIssues: topo.metrics.fanIssues,
      avgHops: topo.metrics.avgHops,
      complexityScore: topo.metrics.complexityScore,
      healthScore: topo.metrics.healthScore,
      cycleDetails: topo.cycles.map(c => c.slice(0, -1).join(" → ")),
      fanDetails: topo.fanIssues.map(f => `${f.type} at ${f.qm} (degree ${f.degree})`),
      unusedChannels: topo.unused.map(e => e.channel_name),
    };
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: "You are an IBM MQ architecture expert. Analyze MQ topology issues and provide concise, actionable transformation guidance. Use clear sections with emojis. Be specific and technical.",
          messages: [{
            role: "user",
            content: `Analyze this IBM MQ topology and provide a transformation roadmap:\n\n${JSON.stringify(summary, null, 2)}\n\nProvide:\n1. Architecture Assessment (2-3 sentences)\n2. Top 3 Priority Actions (numbered, specific)\n3. Modern Pattern Recommendations (event-driven, hub-spoke, etc.)\n4. Risk & Migration Notes\n\nBe concise and actionable.`
          }]
        })
      });
      const data = await res.json();
      setAiText(data.content?.[0]?.text || "No response received.");
    } catch (e) {
      setAiText("Unable to reach AI service. Please check your connection.");
    }
    setAiLoading(false);
  };

  // Gauge SVG for health score
  const HealthGauge = ({ score }) => {
    const color = score > 70 ? C.green : score > 40 ? C.yellow : C.red;
    const angle = -135 + (score / 100) * 270;
    const rad = (angle * Math.PI) / 180;
    const cx = 70, cy = 70, r = 54;
    const x = cx + r * Math.cos(rad);
    const y = cy + r * Math.sin(rad);
    return (
      <svg width="140" height="100" viewBox="0 0 140 100">
        <defs>
          <linearGradient id="gauge-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={C.red} />
            <stop offset="50%" stopColor={C.yellow} />
            <stop offset="100%" stopColor={C.green} />
          </linearGradient>
        </defs>
        <path d={`M ${cx - r * Math.cos(Math.PI * 45 / 180)} ${cy - r * Math.sin(Math.PI * 45 / 180)} A ${r} ${r} 0 1 1 ${cx + r * Math.cos(Math.PI * 45 / 180)} ${cy - r * Math.sin(Math.PI * 45 / 180)}`}
          fill="none" stroke="#1a2e50" strokeWidth="12" strokeLinecap="round" />
        <path d={`M ${cx - r * Math.cos(Math.PI * 45 / 180)} ${cy - r * Math.sin(Math.PI * 45 / 180)} A ${r} ${r} 0 1 1 ${cx + r * Math.cos(Math.PI * 45 / 180)} ${cy - r * Math.sin(Math.PI * 45 / 180)}`}
          fill="none" stroke="url(#gauge-grad)" strokeWidth="12" strokeLinecap="round"
          strokeDasharray={`${(score / 100) * 254} 254`} />
        <line x1={cx} y1={cy} x2={x} y2={y} stroke={color} strokeWidth="2.5" strokeLinecap="round" />
        <circle cx={cx} cy={cy} r="5" fill={color} />
        <text x={cx} y={cy + 24} textAnchor="middle" fill={color} fontSize="20" fontWeight="700" fontFamily={font}>{score}</text>
        <text x={cx} y={cy + 36} textAnchor="middle" fill={C.muted} fontSize="8" fontFamily={font}>HEALTH</text>
      </svg>
    );
  };

  return (
    <div style={S.app}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0} ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-track{background:#0b1628} ::-webkit-scrollbar-thumb{background:#1a2e50;border-radius:3px}
        button:focus{outline:none}`}</style>

      {/* Header */}
      <div style={S.hdr}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={S.logoBox}>⬡</div>
          <div>
            <div style={{ fontSize: 17, fontWeight: 700, letterSpacing: "-0.01em" }}>
              MQ<span style={{ color: C.accent }}>Optima</span>
            </div>
            <div style={{ fontSize: 10, color: C.muted }}>IBM MQ Topology Intelligence Platform</div>
          </div>
        </div>
        {topo && (
          <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
            {[
              { label: "QMs", val: topo.metrics.totalQMs, c: C.blue },
              { label: "Channels", val: topo.metrics.totalChannels, c: C.accent },
              { label: "Cycles", val: topo.metrics.cycles, c: topo.metrics.cycles > 0 ? C.red : C.green },
              { label: "Issues", val: topo.metrics.unusedChannels + topo.metrics.fanIssues, c: C.yellow },
            ].map(m => (
              <div key={m.label} style={{ textAlign: "center" }}>
                <div style={{ fontSize: 18, fontWeight: 700, color: m.c }}>{m.val}</div>
                <div style={{ fontSize: 10, color: C.muted, textTransform: "uppercase" }}>{m.label}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={S.main}>
        {/* Upload Zone */}
        <div style={S.upload(drag)}
          onDragOver={e => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={e => { e.preventDefault(); setDrag(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
          onClick={() => document.getElementById("fi").click()}>
          <input id="fi" type="file" accept=".csv" style={{ display: "none" }} onChange={e => e.target.files[0] && handleFile(e.target.files[0])} />
          <div style={{ fontSize: 28, marginBottom: 6 }}>📂</div>
          <div style={{ color: C.muted, fontSize: 12 }}>
            {loading ? "⚙ Analyzing topology…" : "Drop CSV or click to upload   ·   Demo data active"}
          </div>
          <div style={{ color: C.border, fontSize: 10, marginTop: 6 }}>
            Columns: source_qm, target_qm, channel_name, channel_type, source_queue, target_queue, status, msg_rate, application
          </div>
        </div>

        {topo && (
          <>
            {/* Tabs */}
            <div style={S.tabs}>
              {[
                { id: "overview", label: "Overview" },
                { id: "graph", label: "Topology Graph" },
                { id: "issues", label: `Issues  ${topo.metrics.cycles + topo.metrics.unusedChannels + topo.metrics.fanIssues > 0 ? "●" : ""}` },
                { id: "recommendations", label: "Recommendations" },
                { id: "optimized", label: "Optimized View" },
                { id: "ai", label: "✦ AI Insights" },
              ].map(t => (
                <button key={t.id} style={S.tab(tab === t.id)} onClick={() => setTab(t.id)}>
                  {t.label}
                </button>
              ))}
            </div>

            {/* ─── OVERVIEW ─── */}
            {tab === "overview" && (
              <>
                <div style={{ display: "flex", gap: 16, marginBottom: 18, flexWrap: "wrap", alignItems: "stretch" }}>
                  {/* Gauge */}
                  <div style={{ ...S.card(topo.metrics.healthScore > 70 ? C.green : topo.metrics.healthScore > 40 ? C.yellow : C.red), display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minWidth: 160 }}>
                    <HealthGauge score={topo.metrics.healthScore} />
                    <div style={{ fontSize: 10, color: C.muted, textTransform: "uppercase", letterSpacing: "0.06em" }}>Topology Health</div>
                  </div>
                  {/* Metrics */}
                  <div style={{ flex: 1, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 12 }}>
                    {[
                      { label: "Total Channels", val: topo.metrics.totalChannels, c: C.accent },
                      { label: "Active Channels", val: topo.metrics.activeChannels, c: C.green },
                      { label: "Unused / Dead", val: topo.metrics.unusedChannels, c: C.red },
                      { label: "Queue Managers", val: topo.metrics.totalQMs, c: C.violet },
                      { label: "Cycles Detected", val: topo.metrics.cycles, c: topo.metrics.cycles > 0 ? C.red : C.green },
                      { label: "Fan Violations", val: topo.metrics.fanIssues, c: C.orange },
                      { label: "Avg Hops", val: topo.metrics.avgHops, c: C.blue },
                      { label: "Complexity Score", val: topo.metrics.complexityScore, c: topo.metrics.complexityScore > 50 ? C.red : topo.metrics.complexityScore > 25 ? C.yellow : C.green },
                    ].map(m => (
                      <div key={m.label} style={S.card(m.c)}>
                        <div style={S.metVal(m.c)}>{m.val}</div>
                        <div style={S.metLbl}>{m.label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Complexity Breakdown */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                  <div style={S.sec}>
                    <div style={S.secTitle}>⚡ Complexity Breakdown</div>
                    {[
                      { label: "Cycles", pts: topo.metrics.cycles * 15, max: 60, c: C.red },
                      { label: "Unused Channels", pts: topo.metrics.unusedChannels * 5, max: 40, c: C.yellow },
                      { label: "Fan Violations", pts: topo.metrics.fanIssues * 8, max: 40, c: C.orange },
                      { label: "Hop Overhead", pts: Math.max(0, Math.round((topo.metrics.avgHops - 2) * 8)), max: 30, c: C.blue },
                    ].map(item => (
                      <div key={item.label} style={{ marginBottom: 14 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                          <span style={{ color: C.muted, fontSize: 11 }}>{item.label}</span>
                          <span style={{ color: item.c, fontSize: 11, fontWeight: 600 }}>{item.pts} pts</span>
                        </div>
                        <div style={{ height: 6, background: "#0f1e36", borderRadius: 3 }}>
                          <div style={S.bar(item.max > 0 ? (item.pts / item.max) * 100 : 0, item.c)} />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div style={S.sec}>
                    <div style={S.secTitle}>📉 Optimization Potential</div>
                    {[
                      { label: "Channels (current → optimized)", before: topo.metrics.totalChannels, after: topo.optMetrics.activeChannels, c: C.green },
                      { label: "Cycles → eliminated", before: topo.metrics.cycles, after: 0, c: C.red },
                      { label: "Avg hops", before: topo.metrics.avgHops, after: topo.optMetrics.avgHops, c: C.blue },
                      { label: "Complexity score", before: topo.metrics.complexityScore, after: topo.optMetrics.complexityScore, c: C.yellow },
                      { label: "Health score", before: topo.metrics.healthScore, after: topo.optMetrics.healthScore, c: C.green },
                    ].map(item => (
                      <div key={item.label} style={{ display: "flex", justifyContent: "space-between", padding: "9px 0", borderBottom: `1px solid ${C.border}` }}>
                        <span style={{ color: C.muted, fontSize: 11 }}>{item.label}</span>
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <span style={{ color: "#475569", fontSize: 13 }}>{item.before}</span>
                          <span style={{ color: C.border, fontSize: 10 }}>→</span>
                          <span style={{ color: item.c, fontSize: 13, fontWeight: 700 }}>{item.after}</span>
                          {item.before !== item.after && (
                            <span style={{ fontSize: 10, color: item.after < item.before ? C.green : C.red }}>
                              {item.after < item.before ? `▼ ${item.before - item.after}` : `▲ ${item.after - item.before}`}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* ─── GRAPH ─── */}
            {tab === "graph" && (
              <div style={S.sec}>
                <div style={S.secTitle}>🔗 Current MQ Topology — Original State</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 14, marginBottom: 14 }}>
                  {[
                    { c: C.green, label: "Active channel", dashed: false },
                    { c: C.yellow, label: "Cycle edge", dashed: false },
                    { c: "#ef444455", label: "Unused / STOPPED", dashed: true },
                    { c: C.red, label: "Node in cycle" },
                    { c: C.yellow, label: "High fan-in node" },
                    { c: "#a855f7", label: "High fan-out node" },
                    { c: C.blue, label: "Normal QM" },
                  ].map(l => (
                    <div key={l.label} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                      <div style={{ width: 22, height: 0, borderTop: `2.5px ${l.dashed ? "dashed" : "solid"} ${l.c}` }} />
                      <span style={{ fontSize: 10, color: C.muted }}>{l.label}</span>
                    </div>
                  ))}
                </div>
                <ForceGraph nodes={topo.nodes} edges={topo.edges} height={500} />
                <div style={{ fontSize: 10, color: C.muted, marginTop: 8 }}>Drag to reposition · Scroll to zoom · Hover edges and nodes for details</div>
              </div>
            )}

            {/* ─── ISSUES ─── */}
            {tab === "issues" && (
              <>
                <div style={S.sec}>
                  <div style={S.secTitle}>🔴 Routing Cycles ({topo.cycles.length})</div>
                  {topo.cycles.length === 0
                    ? <div style={{ color: C.green, fontSize: 12 }}>✓ No cycles detected</div>
                    : topo.cycles.map((cycle, i) => {
                      const cycleEdges = [];
                      for (let j = 0; j < cycle.length - 1; j++) {
                        const e = topo.edges.find(e => e.source_qm === cycle[j] && e.target_qm === cycle[j + 1]);
                        if (e) cycleEdges.push(e);
                      }
                      const minE = cycleEdges.length > 0 ? cycleEdges.reduce((m, e) => e.msg_rate < m.msg_rate ? e : m, cycleEdges[0]) : null;
                      return (
                        <div key={i} style={S.issueRow(C.red)}>
                          <div style={{ paddingTop: 1 }}><span style={S.badge(C.red)}>CYCLE</span></div>
                          <div>
                            <div style={{ marginBottom: 5, fontWeight: 600 }}>{cycle.slice(0, -1).join(" → ")} ↻</div>
                            <div style={{ color: C.muted, fontSize: 11, lineHeight: 1.6 }}>
                              {cycle.length - 1} hop(s) · Applications: {[...new Set(cycleEdges.map(e => e.application).filter(Boolean))].join(", ") || "N/A"}<br />
                              {minE && <span>Suggested break point: <span style={{ color: C.yellow }}>{minE.channel_name}</span> ({minE.msg_rate} msg/day — lowest traffic)</span>}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>

                <div style={S.sec}>
                  <div style={S.secTitle}>🟡 Unused / Inactive Channels ({topo.unused.length})</div>
                  {topo.unused.length === 0
                    ? <div style={{ color: C.green, fontSize: 12 }}>✓ No unused channels</div>
                    : topo.unused.map(e => (
                      <div key={e.channel_name} style={S.issueRow(C.yellow)}>
                        <span style={S.badge(C.yellow)}>UNUSED</span>
                        <div>
                          <div style={{ fontWeight: 600, marginBottom: 4 }}>{e.channel_name}</div>
                          <div style={{ color: C.muted, fontSize: 11 }}>
                            {e.source_qm} → {e.target_qm} · Status: <span style={{ color: C.red }}>{e.status}</span> · Traffic: {e.msg_rate} msg/day · App: {e.application || "N/A"}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>

                <div style={S.sec}>
                  <div style={S.secTitle}>🟠 Fan-In / Fan-Out Violations ({topo.fanIssues.length})</div>
                  {topo.fanIssues.length === 0
                    ? <div style={{ color: C.green, fontSize: 12 }}>✓ No fan pattern violations (threshold: degree &gt; 3)</div>
                    : topo.fanIssues.map((f, i) => (
                      <div key={i} style={S.issueRow(C.orange)}>
                        <span style={S.badge(C.orange)}>{f.type.replace("_", "-")}</span>
                        <div>
                          <div style={{ fontWeight: 600, marginBottom: 4 }}>{f.qm} — degree {f.degree}</div>
                          <div style={{ color: C.muted, fontSize: 11 }}>
                            {f.type === "FAN_IN" ? "Receives from" : "Sends to"}: {f.peers.join(", ")}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </>
            )}

            {/* ─── RECOMMENDATIONS ─── */}
            {tab === "recommendations" && (
              <div style={S.sec}>
                <div style={S.secTitle}>🎯 Actionable Recommendations ({topo.recommendations.length})</div>
                <div style={{ marginBottom: 16, display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 11, color: C.muted }}>Total channels reducible:</span>
                  <span style={{ color: C.green, fontWeight: 700 }}>
                    −{topo.recommendations.reduce((s, r) => s + r.channelsReduced, 0)}
                  </span>
                </div>
                {topo.recommendations.map(rec => (
                  <div key={rec.id} style={S.recCard(priorityColor[rec.priority] || C.border)}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10, flexWrap: "wrap", gap: 8 }}>
                      <div style={{ display: "flex", gap: 7, alignItems: "center" }}>
                        <span style={{ color: C.muted, fontSize: 10 }}>{rec.id}</span>
                        <span style={S.badge(priorityColor[rec.priority] || C.muted)}>{rec.priority}</span>
                        <span style={S.badge(C.muted)}>{rec.category}</span>
                      </div>
                      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                        <span style={{ fontSize: 10, color: C.muted }}>Effort:</span>
                        <span style={S.badge(effortColor[rec.effort] || C.muted)}>{rec.effort}</span>
                        <span style={{ fontSize: 10, color: C.green }}>−{rec.channelsReduced} channels</span>
                      </div>
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 7 }}>{rec.title}</div>
                    <div style={{ fontSize: 11, color: C.muted, marginBottom: 10, lineHeight: 1.65 }}>{rec.description}</div>
                    <div style={{ fontSize: 11, color: C.green, background: C.green + "12", padding: "7px 12px", borderRadius: 7 }}>
                      ↑ {rec.impact}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ─── OPTIMIZED ─── */}
            {tab === "optimized" && (
              <>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 14, marginBottom: 18 }}>
                  {[
                    { label: "Channels Removed", val: `−${topo.metrics.totalChannels - topo.optMetrics.activeChannels}`, c: C.green },
                    { label: "Cycles Eliminated", val: `−${topo.metrics.cycles}`, c: C.green },
                    { label: "Complexity Delta", val: `−${topo.metrics.complexityScore - topo.optMetrics.complexityScore} pts`, c: C.green },
                    { label: "New Health Score", val: topo.optMetrics.healthScore, c: topo.optMetrics.healthScore > 70 ? C.green : C.yellow },
                    { label: "Remaining Channels", val: topo.optMetrics.activeChannels, c: C.accent },
                    { label: "New Avg Hops", val: topo.optMetrics.avgHops, c: C.blue },
                  ].map(m => (
                    <div key={m.label} style={S.card(m.c)}>
                      <div style={S.metVal(m.c)}>{m.val}</div>
                      <div style={S.metLbl}>{m.label}</div>
                    </div>
                  ))}
                </div>
                <div style={S.sec}>
                  <div style={S.secTitle}>✨ Optimized Topology — Post-Transformation</div>
                  <div style={{ display: "flex", gap: 10, marginBottom: 12, flexWrap: "wrap" }}>
                    <span style={{ ...S.badge(C.red), marginRight: 4 }}>Removed</span>
                    <span style={{ fontSize: 11, color: C.muted }}>Unused channels removed · Cycle-breaking edges eliminated · Simplified routing paths</span>
                  </div>
                  <ForceGraph nodes={topo.opt.nodes} edges={topo.opt.edges} height={500} />
                </div>
              </>
            )}

            {/* ─── AI INSIGHTS ─── */}
            {tab === "ai" && (
              <div>
                <div style={S.aiBox}>
                  <div style={{ ...S.secTitle, color: C.violet }}>✦ AI-Powered Architecture Analysis</div>
                  <div style={{ fontSize: 11, color: C.muted, marginBottom: 16, lineHeight: 1.7 }}>
                    Send the topology analysis to Claude for an expert assessment of transformation strategies, risk areas, and modernization patterns tailored to your MQ environment.
                  </div>
                  <button
                    onClick={fetchAI}
                    disabled={aiLoading}
                    style={{ padding: "10px 24px", background: aiLoading ? C.sur2 : `linear-gradient(135deg, ${C.violet}, ${C.accent}30)`, border: `1px solid ${C.violet}`, borderRadius: 8, color: C.text, fontFamily: font, fontSize: 12, cursor: aiLoading ? "wait" : "pointer", fontWeight: 600, letterSpacing: "0.04em" }}>
                    {aiLoading ? "⚙ Analyzing…" : "✦ Run AI Analysis"}
                  </button>
                </div>

                {/* Context sent to AI */}
                <div style={{ ...S.sec, marginBottom: 18 }}>
                  <div style={S.secTitle}>📋 Context Summary (sent to AI)</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    {[
                      ["Queue Managers", topo.metrics.totalQMs],
                      ["Total Channels", topo.metrics.totalChannels],
                      ["Unused Channels", topo.metrics.unusedChannels],
                      ["Routing Cycles", topo.metrics.cycles],
                      ["Fan Violations", topo.metrics.fanIssues],
                      ["Avg Routing Hops", topo.metrics.avgHops],
                      ["Complexity Score", topo.metrics.complexityScore],
                      ["Health Score", topo.metrics.healthScore],
                    ].map(([k, v]) => (
                      <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: `1px solid ${C.border}` }}>
                        <span style={{ color: C.muted, fontSize: 11 }}>{k}</span>
                        <span style={{ fontWeight: 600, fontSize: 11 }}>{v}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {aiText && (
                  <div style={{ ...S.sec, borderColor: C.violet + "40" }}>
                    <div style={{ ...S.secTitle, color: C.violet }}>✦ AI Analysis Result</div>
                    <div style={{ fontSize: 12, color: C.text, lineHeight: 1.8, whiteSpace: "pre-wrap" }}>{aiText}</div>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
